# coding: utf-8
__author__ = 'mancuniancol'

html = '''

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.elitetorrent.net/" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="peliculas gratis, descargas torrents, bittorrent, torrents, descargar peliculas, utorrent, bitcomet, descargas gratis" />
<meta name="Description" content="Web para descargas torrents, estrenos, peliculas, series, juegos y mucho más totalmente libre y gratuito" />
<meta name="propeller" content="6abb62b31cad4c986857d7d1f76920d0" />
<link rel="image_src" href="http://www.elitetorrent.net/elitetorrent2010_msn.jpg" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
<script language="JavaScript" type="text/javascript" src="javascripts/general.js?act=1"></script>
<script language="JavaScript" type="text/javascript" src="javascripts/jquery.cookie.js"></script>
<link href="estilos.css?act=7" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
<title>Busqueda: tarzan - EliteTorrent.net</title>
</head>
<body>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-284045-1', 'auto');
  ga('send', 'pageview');

</script>
<script type="text/javascript" src="http://www.elitegol.com/lanzalayer.php"></script><!-- CODIGO AD DEL TOP -->
<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://pubted.com/www/delivery/ajs.php':'http://pubted.com/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?zoneid=1189&amp;source=");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://pubted.com/www/delivery/ck.php?n=acd9fc4d&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://pubted.com/www/delivery/avw.php?zoneid=1189&amp;source=&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=acd9fc4d' border='0' alt='' /></a></noscript>
<!-- FIN CODIGO AD --><div id="cab_content"><div id="cabecera">
	<div class="cab_logo">
		<a href="/"><img src="/images/logo_elite.png" border="0" alt="logo"/></a>
	</div>
	<div class="cab_buscar">
		<form class="form-buscar" method="post" action="buscar.php">
		<input name="buscar" type="text" class="campo-buscar" value="Buscar torrent..." onclick="this.value=''; this.onclick=''"/>
		<input type="image" value="Buscar" class="boton-buscar" src="/images/lupa.png"/></form>
	</div>
	<div class="cab_menu"><a href="/descargas">DESCARGAS</a> | <a href="http://www.eliteforo.com" target="_blank">FORO</a> | <a href="/log">LOG</a> | <a href="/tablon">TABLÓN</a></div>
	<div class="cab_usuario"><a href="/login">Iniciar sesión</a> | <a href="/registro">Crear cuenta</a></div>
	</div>
	</div>

    <div id="cabecera-categorias"><div class="wrap"><a href="/categoria/6/docus-y-tv">Docus y TV</a><a href="/categoria/1/estrenos">Estrenos</a><a href="/categoria/2/peliculas">Peliculas</a><a href="/categoria/13/peliculas-hdrip">Peliculas HDRip</a><a href="/categoria/17/peliculas-microhd">Peliculas microHD</a><a href="/categoria/14/peliculas-vose">Peliculas VOSE</a><a href="/categoria/4/series">Series</a><a href="/categoria/16/series-vose">Series VOSE</a><a href="http://www.elitegol.com" target="_blank" style="color:#0066FF;font-weight:bold;">Futbol online</a><a href="http://www.tripledeseo.com" target="_blank" style="color:#FF3399;font-weight:bold;">Descargas porno</a><a href="http://www.aypornoes.com" alt="Vídeos porno" title="Vídeos porno" target="_blank" style="color:#FF0055;font-weight:bold;">Vídeos porno</a></div></div>
	<div id="cuerpo"><div id="principal"><!-- CODIGO AD DEL BANNER TOP (DEFECTO) 728x90 -->
<div align="center">
<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://pubted.com/www/delivery/ajs.php':'http://pubted.com/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?zoneid=1183");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://pubted.com/www/delivery/ck.php?n=a7a8989c&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://pubted.com/www/delivery/avw.php?zoneid=1183&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a7a8989c' border='0' alt='' /></a></noscript>
</div>
<!-- FIN CODIGO AD --><div class="box-seccion"><div class="nav">
			<h3>Busqueda: tarzan (total 4)</h3>
			<div class="nav-orden">
				<a href="/resultados/tarzan" class="activo"><img src="/images/modoficha.png" border="0"/></a>
				<a href="/resultados/tarzan/modo:mini" ><img src="/images/modolistado.png" border="0"/></a>
				<a href="/resultados/tarzan/modo:listado" ><img src="/images/modotabla.png" border="0"/></a>
				<a href="/resultados/tarzan/orden:valoracion" >Valoración</a>
				<a href="/resultados/tarzan/orden:popularidad" >Popularidad</a>
				<a href="/resultados/tarzan/orden:nombre" >Nombre</a>
				<a href="/resultados/tarzan" class="activo">Fecha</a>
			</div>
		</div><ul class="miniboxs miniboxs-ficha"><li>
				<a href="/torrent/25083/tarzan-microhd"><img src="thumb_fichas/25083.jpg" border="0" title="Tarzan (microHD)" alt="IMG: Tarzan (microHD)"/></a>
				<div class="meta"><span class="voto1" title="Valoracion media">6.8</span><a class="nombre" href="/torrent/25083/tarzan-microhd" title="Tarzan (microHD)">Tarzan (microHD)</a>
				<span class="categoria">Peliculas microHD</span>
				<span class="fecha">Hace 2 años</span>
				</div>
				</li><li>
				<a href="/torrent/25082/tarzan-hdrip"><img src="thumb_fichas/25082.jpg" border="0" title="Tarzan (HDRip)" alt="IMG: Tarzan (HDRip)"/></a>
				<div class="meta"><span class="voto1" title="Valoracion media">5.8</span><span class="voto2" title="Valoracion de la calidad de vídeo/audio" style="background-color:rgb(60,170,0)">8.4</span><a class="nombre" href="/torrent/25082/tarzan-hdrip" title="Tarzan (HDRip)">Tarzan (HDRip)</a>
				<span class="categoria">Peliculas HDRip</span>
				<span class="fecha">Hace 2 años</span>
				</div>
				</li><li>
				<a href="/torrent/23940/tarzan-br-line"><img src="thumb_fichas/23940.jpg" border="0" title="Tarzan (BR-Line)" alt="IMG: Tarzan (BR-Line)"/></a>
				<div class="meta"><a class="nombre" href="/torrent/23940/tarzan-br-line" title="Tarzan (BR-Line)">Tarzan (BR-Line)</a>
				<span class="categoria">Estrenos</span>
				<span class="fecha">Hace 2 años</span>
				</div>
				</li><li>
				<a href="/torrent/23859/tarzan-2013-br-screener"><img src="thumb_fichas/23859.jpg" border="0" title="Tarzan (2013) (BR-Screener)" alt="IMG: Tarzan (2013) (BR-Screener)"/></a>
				<div class="meta"><a class="nombre" href="/torrent/23859/tarzan-2013-br-screener" title="Tarzan (2013) (BR-Screener)">Tarzan (2013) (BR-Screener)</a>
				<span class="categoria">Estrenos</span>
				<span class="fecha">Hace 2 años</span>
				</div>
				</li></ul><div class="paginacion"><span class="pagina pag_actual">1</span></div></div><!-- CODIGO AD DEL BANNER PIE 728x90 -->
<!-- FIN CODIGO AD --></div><div id="menu" align="center"><br/><a href="http://www.facebook.com/elitetorrent.net"
		style="display:block;font-weight:bold;padding:3px 6px;background-color:#03F;color:#FFF;font-size:18px;margin-bottom:10px;"
		target="_blank">Seguir Facebook</a>
		<a href="http://www.twitter.com/elite_torrent"
		style ="display:block;font-weight:bold;padding:3px 6px;background-color:#39F;color:#FFF;font-size:18px;margin-bottom:10px;"
		target="_blank">Seguir Twitter</a><!-- CODIGO AD DEL BANNER TORRE 1 - 160x600 -->
<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://pubted.com/www/delivery/ajs.php':'http://pubted.com/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?zoneid=3442");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://pubted.com/www/delivery/ck.php?n=ab3f9348&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://pubted.com/www/delivery/avw.php?zoneid=3442&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=ab3f9348' border='0' alt='' /></a></noscript>
<br><br>
<!-- FIN CODIGO AD --><!-- CODIGO AD DEL BANNER TORRE 2 - 160x600 -->
<div align="center">
<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://pubted.com/www/delivery/ajs.php':'http://pubted.com/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?zoneid=1182&amp;source=VARIABLE");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://pubted.com/www/delivery/ck.php?n=a14ea783&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://pubted.com/www/delivery/avw.php?zoneid=1182&amp;source=VARIABLE&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a14ea783' border='0' alt='' /></a></noscript>
<br><br>
</div>
<!-- FIN CODIGO AD --><!-- CODIGO AD DEL BANNER TORRE 3 - 160x600 -->
<div align="center">
<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://pubted.com/www/delivery/ajs.php':'http://pubted.com/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?zoneid=1182&amp;source=VARIABLE");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://pubted.com/www/delivery/ck.php?n=a14ea783&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://pubted.com/www/delivery/avw.php?zoneid=1182&amp;source=VARIABLE&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a14ea783' border='0' alt='' /></a></noscript>
<br><br>
</div>
<!-- FIN CODIGO AD --></div></div>
<div id="fondo-pie">
	<div id="pie"><script language="javascript" src="http://www.grupoet.com/ewn_pie.php" type="text/javascript"></script><br/><div id="pie2">Web creada por <a href="http://www.elitewebsnetwork.com" target="_blank">EliteWebs Network</a> en 2004 (c) Elitetorrent.net
  <p>
    <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><img
      src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>
  </p>
<br/><a href="http://www.ademails.com/estadisticas1059827344.htm" rel="nofollow">
<script type="text/javascript" language="JavaScript">
<!--
document.write("<img src=\"http://www.ademails.com/cgi-bin/contador.cgi?ID=1059827344");
document.write("&referer=");
document.write(escape(document.referrer));
document.write("\" border=0 alt=\"Estadisticas\">");
// -->
</script>
</a>
<br/><br/>
<a href="/datos-legales.html" target="_blank" style="text-decoration:underline;">Datos legales</a>
		</div>
	</div>
</div><!-- CODIGO AD DEL POPUP -->
<script src="http://yesobe.work/w/d/a2.php?z=731" type="text/javascript"></script>
<!-- FIN CODIGO AD --><!-- CODIGO AD DEL MOBILE  -->
<!-- FIN CODIGO AD --><!-- IP: 70.53.204.159 -->
	</body>
	</html>
'''

from ehp import Html

dom = Html().feed(html)
# for item in dom.find_once('ul', ('class', 'miniboxs miniboxs-ficha')).find_all('li'):
#     name = item(tag='img', attribute='title')
#     temp = item(tag='a', attribute='href')
#     magnet = temp[:temp.rfind('/')].replace('/torrent/', '/get-torrent/')
#     size = None
#     seeds = ""
#     peers = ""
#     print name
#     print magnet
#     # print size
#     # print seeds
#     # print peers
#     print '**************'

row_search = "dom." + "find_all('li')"
name_search = "item(tag='img', attribute='title')"
info_hash_search = ""
magnet_search = "item(tag='a', attribute='href').replace('/torrent/', '/get-torrent/')"
size_search = "None"
seeds_search = ""
peers_search = ""
if dom is not None:
    for item in eval(row_search):
        if item is not None:
            name = eval(name_search)  # name
            magnet = eval(magnet_search) if len(magnet_search) > 0 else ""  # magnet
            info_hash = eval(info_hash_search) if len(info_hash_search) > 0 else ""  # size
            size = eval(size_search) if len(size_search) > 0 else ""  # size
            seeds = eval(seeds_search) if len(seeds_search) > 0 else ""  # seeds
            peers = eval(peers_search) if len(peers_search) > 0 else ""  # peers
            print (name, info_hash, magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers