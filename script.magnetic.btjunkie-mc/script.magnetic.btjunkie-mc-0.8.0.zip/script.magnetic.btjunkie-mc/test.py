# coding: utf-8
__author__ = 'mancuniancol'

html = '''

<!DOCTYPE html><html class="notlogged searched noscript search" xmlns="http://www.w3.org/1999/xhtml" lang=""><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="Content-Script-Type" content="text/javascript" /><meta http-equiv="Content-Style-Type" content="text/css" /><meta name="viewport" content="width=device-width"><meta http-equiv="Content-Language" content="en" /><title>All Torrents Matching 'tarzan 2016' - BtJunkie</title><meta name="title" content="All Torrents Matching 'tarzan 2016' - BtJunkie" /><meta property="og:title" content="All Torrents Matching 'tarzan 2016' - BtJunkie" /><meta name="Description" content="Search results for 'tarzan 2016' in the category All" /><meta property="og:description" content="Search results for 'tarzan 2016' in the category All" /><meta property="og:keywords" content="All, tarzan 2016, search, direct, download, bittorrent, torrent, magnet, bt, btj, btjunkie"><meta name="keywords" content="All, tarzan 2016, search, direct, download, bittorrent, torrent, magnet, bt, btj, btjunkie"><meta property="og:image" content="/img/logo.png" /><link rel="image_src" href="/img/logo.png" /><link rel="shortcut icon" href="/img/favicon1.ico" type="image/x-icon"><link rel="search" type="application/opensearchdescription+xml" href="http://btjunkie.eu/Sitemap.xml" title="All Torrents Matching 'tarzan 2016' - BtJunkie" /><link rel="alternate" type="application/rss+xml" title="All Torrents Matching 'tarzan 2016' - BtJunkie" href="http://btjunkie.eu/last_added.xml" /><meta property="og:site_name" content="BtJunkie" /><link rel="shortcut icon" href="/favicon.ico" /><link rel="stylesheet" href="/css/style.css" /><link rel="stylesheet" href="/css/user.css" /><link rel="stylesheet" href="/css/font-awesome.min.css" /><link rel="stylesheet" href="/css/rb.css" /><!--[if lt IE 9]>  <link rel="stylesheet" media="all" type="text/css" href="/css/ie.css" /><![endif]--><noscript><link rel="stylesheet" href="/css/noscript.css" /></noscript></head><body><div id="scriptHolder"></div><script type="text/javascript" src="/js/libs/modernizer.js"></script><div id="fb-root"></div><script type="text/javascript">if(top.location!=location && top.location!='http://www.youlikehits.com/addplusone.php?step=submit'){top.location.href=document.location.href;}</script><div id="modal" onclick="dialogHide();"></div><div style="display: none;" class="dialog" id="globalLoad">Loading Please Wait: <br /><img src="/images/loading.gif" title="Loading.." alt="Loading.." /></div><header id="main_header">
    <div id="user_form_btn">Login / Register</div><div id="user_box"><div id="toggle_user_menu" title=" Menu"><img src="/img/user.png" style="vertical-align: middle;" height="38"/></div><ul id="user_menu" class="pop" data-pop='{"popper": "#toggle_user_menu"}'><li class="username" id="userHeader" data-user-id="0"><span></span></li><li><a title=" profile" href="/user//profile">Profile</a></li><li><a title=" messages" href="/user//messages">Messages </a></li><li><a title=" torrents history" href="/user//history">History</a></li><li><a title=" bookmarked torrents" href="/user//bookmarks">Bookmarks</a></li><li><a title=" settings" href="/user//settings">Settings</a></li><li><a title="Log Out" href="http://btjunkie.eu/logout/%2Fall%2Ftype-all%2Fby-seed%2Fdesc%2Fpage1%2Ftarzan%25202016" id="exit-btn">Log Out</a></li></ul></div>    <div id="toggle_menu">
        <span class="menu_icon"></span>
        <span class="menu_icon"></span>
        <span class="menu_icon"></span>
    </div>
    <div id="tag-cloud">
        <div id="tags-box"></div>
    </div>
    <div id="search_form" class="clearfix">
        <!--SEARCH BOX-->

        <input type="hidden"  name="category" value="all" />

        <div id="search_box">
            <h2 id="logo_h1">                <a title="BtJunkie Home" href="http://btjunkie.eu">
                    <img alt="" id="logo" class="f1" src="/img/logo8.png"/>                </a>
            </h2>
            <div id="search_frame">
                <div id="srch-wrap">
                    <div id="srch-tag">
                        <button id="srch-tag-btn" data-url="" class="video">
                            <span class="icon"></span>
                            <span id="srch-tag-label">Video</span>
                        </button>
                        <button id="srch-tag-close">
                            <span class="icon"></span>
                        </button>
                        <ul id="srch-tag-list" class="pop" data-pop='{"popper": "#srch-wrap,#advanced_search_list"}'>
                        <li><a href="http://btjunkie.eu/video/type-3d-movies" data-name="3D Movies" data-val="3d movies" class="srch-tag-item video" title="Download 3D Movies Torrents">3D Movies</a></li><li><a href="http://btjunkie.eu/video/type-anime" data-name="Anime" data-val="anime" class="srch-tag-item video" title="Download Anime Torrents">Anime</a></li><li><a href="http://btjunkie.eu/video/type-handheld" data-name="Handheld" data-val="handheld" class="srch-tag-item video" title="Download Handheld Torrents">Handheld</a></li><li><a href="http://btjunkie.eu/video/type-movie-clips" data-name="Movie clips" data-val="movie clips" class="srch-tag-item video" title="Download Movie clips Torrents">Movie clips</a></li><li><a href="http://btjunkie.eu/video/type-movies" data-name="Movies" data-val="movies" class="srch-tag-item video" title="Download Movies Torrents">Movies</a></li><li><a href="http://btjunkie.eu/video/type-music-videos" data-name="Music videos" data-val="music videos" class="srch-tag-item video" title="Download Music videos Torrents">Music videos</a></li><li><a href="http://btjunkie.eu/video/type-tv" data-name="TV" data-val="tv" class="srch-tag-item video" title="Download TV Torrents">TV</a></li><li><a href="http://btjunkie.eu/video/type-other" data-name="Other" data-val="other" class="srch-tag-item video" title="Download Other Torrents">Other</a></li><li><a href="http://btjunkie.eu/audio/type-audio-books" data-name="Audio books" data-val="audio books" class="srch-tag-item audio" title="Download Audio books Torrents">Audio books</a></li><li><a href="http://btjunkie.eu/audio/type-flac" data-name="FLAC" data-val="flac" class="srch-tag-item audio" title="Download FLAC Torrents">FLAC</a></li><li><a href="http://btjunkie.eu/audio/type-music" data-name="Music" data-val="music" class="srch-tag-item audio" title="Download Music Torrents">Music</a></li><li><a href="http://btjunkie.eu/audio/type-soundtrack" data-name="Soundtrack" data-val="soundtrack" class="srch-tag-item audio" title="Download Soundtrack Torrents">Soundtrack</a></li><li><a href="http://btjunkie.eu/audio/type-other" data-name="Other" data-val="other" class="srch-tag-item audio" title="Download Other Torrents">Other</a></li><li><a href="http://btjunkie.eu/games/type-android" data-name="Android" data-val="android" class="srch-tag-item games" title="Download Android Torrents">Android</a></li><li><a href="http://btjunkie.eu/games/type-handheld" data-name="Handheld" data-val="handheld" class="srch-tag-item games" title="Download Handheld Torrents">Handheld</a></li><li><a href="http://btjunkie.eu/games/type-ios" data-name="iOS" data-val="ios" class="srch-tag-item games" title="Download iOS Torrents">iOS</a></li><li><a href="http://btjunkie.eu/games/type-linux" data-name="Linux" data-val="linux" class="srch-tag-item games" title="Download Linux Torrents">Linux</a></li><li><a href="http://btjunkie.eu/games/type-mac" data-name="Mac" data-val="mac" class="srch-tag-item games" title="Download Mac Torrents">Mac</a></li><li><a href="http://btjunkie.eu/games/type-nds" data-name="NDS" data-val="nds" class="srch-tag-item games" title="Download NDS Torrents">NDS</a></li><li><a href="http://btjunkie.eu/games/type-pc" data-name="PC" data-val="pc" class="srch-tag-item games" title="Download PC Torrents">PC</a></li><li><a href="http://btjunkie.eu/games/type-psp" data-name="PSP" data-val="psp" class="srch-tag-item games" title="Download PSP Torrents">PSP</a></li><li><a href="http://btjunkie.eu/games/type-ps" data-name="PS" data-val="ps" class="srch-tag-item games" title="Download PS Torrents">PS</a></li><li><a href="http://btjunkie.eu/games/type-wii" data-name="Wii" data-val="wii" class="srch-tag-item games" title="Download Wii Torrents">Wii</a></li><li><a href="http://btjunkie.eu/games/type-xbox" data-name="XBOX" data-val="xbox" class="srch-tag-item games" title="Download XBOX Torrents">XBOX</a></li><li><a href="http://btjunkie.eu/games/type-other" data-name="Other" data-val="other" class="srch-tag-item games" title="Download Other Torrents">Other</a></li><li><a href="http://btjunkie.eu/apps/type-android" data-name="Android" data-val="android" class="srch-tag-item apps" title="Download Android Torrents">Android</a></li><li><a href="http://btjunkie.eu/apps/type-handheld" data-name="Handheld" data-val="handheld" class="srch-tag-item apps" title="Download Handheld Torrents">Handheld</a></li><li><a href="http://btjunkie.eu/apps/type-ios" data-name="iOS" data-val="ios" class="srch-tag-item apps" title="Download iOS Torrents">iOS</a></li><li><a href="http://btjunkie.eu/apps/type-linux" data-name="Linux" data-val="linux" class="srch-tag-item apps" title="Download Linux Torrents">Linux</a></li><li><a href="http://btjunkie.eu/apps/type-mac" data-name="Mac" data-val="mac" class="srch-tag-item apps" title="Download Mac Torrents">Mac</a></li><li><a href="http://btjunkie.eu/apps/type-pc" data-name="PC" data-val="pc" class="srch-tag-item apps" title="Download PC Torrents">PC</a></li><li><a href="http://btjunkie.eu/apps/type-unix" data-name="UNIX" data-val="unix" class="srch-tag-item apps" title="Download UNIX Torrents">UNIX</a></li><li><a href="http://btjunkie.eu/apps/type-windows" data-name="Windows" data-val="windows" class="srch-tag-item apps" title="Download Windows Torrents">Windows</a></li><li><a href="http://btjunkie.eu/apps/type-other" data-name="Other" data-val="other" class="srch-tag-item apps" title="Download Other Torrents">Other</a></li><li><a href="http://btjunkie.eu/other/type-comics" data-name="Comics" data-val="comics" class="srch-tag-item other" title="Download Comics Torrents">Comics</a></li><li><a href="http://btjunkie.eu/other/type-ebooks" data-name="Ebooks" data-val="ebooks" class="srch-tag-item other" title="Download Ebooks Torrents">Ebooks</a></li><li><a href="http://btjunkie.eu/other/type-magazines" data-name="Magazines" data-val="magazines" class="srch-tag-item other" title="Download Magazines Torrents">Magazines</a></li><li><a href="http://btjunkie.eu/other/type-music" data-name="Music" data-val="music" class="srch-tag-item other" title="Download Music Torrents">Music</a></li><li><a href="http://btjunkie.eu/other/type-pictures" data-name="Pictures" data-val="pictures" class="srch-tag-item other" title="Download Pictures Torrents">Pictures</a></li><li><a href="http://btjunkie.eu/other/type-sport" data-name="Sport" data-val="sport" class="srch-tag-item other" title="Download Sport Torrents">Sport</a></li><li><a href="http://btjunkie.eu/other/type-wallpapers" data-name="Wallpapers" data-val="wallpapers" class="srch-tag-item other" title="Download Wallpapers Torrents">Wallpapers</a></li><li><a href="http://btjunkie.eu/other/type-unsorted" data-name="Unsorted" data-val="unsorted" class="srch-tag-item other" title="Download Unsorted Torrents">Unsorted</a></li><li><a href="http://btjunkie.eu/xxx/type-games" data-name="Games" data-val="games" class="srch-tag-item XXX" title="Download Games Torrents">Games</a></li><li><a href="http://btjunkie.eu/xxx/type-hd-video" data-name="HD Video" data-val="hd video" class="srch-tag-item XXX" title="Download HD Video Torrents">HD Video</a></li><li><a href="http://btjunkie.eu/xxx/type-hentai" data-name="Hentai" data-val="hentai" class="srch-tag-item XXX" title="Download Hentai Torrents">Hentai</a></li><li><a href="http://btjunkie.eu/xxx/type-pictures" data-name="Pictures" data-val="pictures" class="srch-tag-item XXX" title="Download Pictures Torrents">Pictures</a></li><li><a href="http://btjunkie.eu/xxx/type-video" data-name="Video" data-val="video" class="srch-tag-item XXX" title="Download Video Torrents">Video</a></li><li><a href="http://btjunkie.eu/xxx/type-other" data-name="Other" data-val="other" class="srch-tag-item XXX" title="Download Other Torrents">Other</a></li>                        </ul>
                    </div>
                    <button type="button" title="Search For Torrents" id="search_btn" class="p1">
                        <!--<img src="/img/search.png" height="30" alt="" title="" />-->
                        <span class="icon srch-btn"></span>
                        <span id="srch-btn-extension">Search torrents</span>
                    </button>
                    <div id="srch-inner-wrap">
                        <div id="srch-in-inner-wrap">
                            <div id="srch-input-frame">
                                                                <input title="Search for Torrents to Download" type="search" autocomplete="off" value="tarzan 2016" name="search" autofocus="autofocus" placeholder="Search" id="search_input" />
                            </div>
                            <ul id="autocomplete" class="pop" data-pop='{"popper": "#search_input"}'>
                                <!--<li class="ac-li"><a href="#0" class="ac-item">Link</a></li>
                                <li class="ac-li selected"><a href="#0" class="ac-item">Link</a></li>
                                <li class="ac-li"><a href="#0" class="ac-item">Some pretty long title that must </a></li>
                                <li class="ac-li"><a href="#0" class="ac-item">Link</a></li>
                                <li class="ac-li"><a href="#0" class="ac-item">Link</a></li>-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!--CHECKBOXES-->
        </div>

        <!--ADVANCED SEARCH BOX-->
        <div id="advanced_search_box">

            <!--BROWSE AND LATEST AND ADVANCED BTN-->
            <a title="Advanced search" role="btn" id="advanced_search_btn">
                <!--<img alt="" src="/img/advanced.png" height="30" title="" />-->
                <span class="icon opt-adv-srch"></span>
                <span>Advanced search</span>
            </a>

            <ul id="browse_options" class="clearfix">
                                <li id="Browse_btn" >
                    <a title="Browse for Torrents" role="btn" name="Browse"   value="Browse" href="http://btjunkie.eu/all">
                    <!--<img height="30" src="/img/Browse.png" alt="Browse" title="Browse" />-->
                    <span class="icon opt-browse"></span>
                    <span>Browse</span>
                    </a>
                </li>
                                <li id="Latest_btn">
                    <a title="Download Latest Torrents" role="btn" name="Latest" value="Latest"   href="http://btjunkie.eu/latest">
                    <!--<img height="30" src="/img/Latest.png" alt="Latest" title="Latest" />-->
                    <span class="icon opt-latest"></span>
                    <span>Latest</span>
                    </a>
                </li>
            </ul>

            <!--ADVANCED SEARCH LIST-->
            <div id="advanced_search_options" class="">
                <ul id="advanced_search_list">
                    <li id="search_All" ><a class="p2" role="btn" class="selected" data-name="All" data-val="all"  href="http://btjunkie.eu/all/by-default_sort/desc/page1/tarzan 2016" title="Download All Torrents"><span class="icon cat-All"></span><span>All</span></a></li><li id="search_Video" ><a class="p2" role="btn"  data-name="Video" data-val="video"  href="http://btjunkie.eu/video/by-default_sort/desc/page1/tarzan 2016" title="Download Video Torrents"><span class="icon cat-Video"></span><span>Video</span></a></li><li id="search_Audio" ><a class="p2" role="btn"  data-name="Audio" data-val="audio"  href="http://btjunkie.eu/audio/by-default_sort/desc/page1/tarzan 2016" title="Download Audio Torrents"><span class="icon cat-Audio"></span><span>Audio</span></a></li><li id="search_Games" ><a class="p2" role="btn"  data-name="Games" data-val="games"  href="http://btjunkie.eu/games/by-default_sort/desc/page1/tarzan 2016" title="Download Games Torrents"><span class="icon cat-Games"></span><span>Games</span></a></li><li id="search_Apps" ><a class="p2" role="btn"  data-name="Apps" data-val="apps"  href="http://btjunkie.eu/apps/by-default_sort/desc/page1/tarzan 2016" title="Download Apps Torrents"><span class="icon cat-Apps"></span><span>Apps</span></a></li><li id="search_Other" ><a class="p2" role="btn"  data-name="Other" data-val="other"  href="http://btjunkie.eu/other/by-default_sort/desc/page1/tarzan 2016" title="Download Other Torrents"><span class="icon cat-Other"></span><span>Other</span></a></li><li id="search_XXX" ><a class="p2" role="btn"  data-name="XXX" data-val="XXX"  href="http://btjunkie.eu/xxx/by-default_sort/desc/page1/tarzan 2016" title="Download XXX Torrents"><span class="icon cat-XXX"></span><span>XXX</span></a></li>                </ul>
            </div>
                                        </div>
        </div>
    </div>
</header>
<script id="popScript" type="application/javascript" src="http://ads.shakeit.click/pop/bb36cc3dabd9a7a4b788cb178c8598c0.js"></script><section id="main_section"><div class="torrents_box"><h3 class="torrents_heading video">Results for <strong class="match">tarzan 2016</strong>: 1 - 20 from 1 097 (0.052s)</h3><table class="torrents_table"><thead><tr><th class="type_td" style="text-align:center">Type</th><th class="title_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-title/desc/page1/tarzan 2016" title="Sort by Title">Title</a></th><th></th><th class="size_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-size/desc/page1/tarzan 2016" title="Sort by Size">Size</a></th><th class="files_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-files/desc/page1/tarzan 2016" title="Sort by Files">Files</a></th><th class="date_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-added/desc/page1/tarzan 2016" title="Sort by Added">Added</a></th><th class="seed_td"><a class="order desc" href="http://btjunkie.eu/all/type-all/by-seed/asc/page1/tarzan 2016" title="Sort by Seed">Seed</a></th><th class="leech_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-leech/desc/page1/tarzan 2016" title="Sort by Leech">Leech</a></th><th class="health_td"><a class="order" href="http://btjunkie.eu/all/type-all/by-health/desc/page1/tarzan 2016" title="Sort by Health">Health</a></th></tr></thead><tbody>            <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34963187/The-Legend-of-Tarzan-2016-720p-BrRip-x264-AMIABLE" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34963187 - The Legend of Tarzan 2016 720p BrRip x264 - AMIABLE" href="/torrent/34963187/The-Legend-of-Tarzan-2016-720p-BrRip-x264-AMIABLE"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - AMIABLE</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:bdc3b8cc94d6ee2b8581800b83fe76496af2a983&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - AMIABLE" href="magnet:?xt=urn:btih:bdc3b8cc94d6ee2b8581800b83fe76496af2a983&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-08</td>
                <td class="seed_td">24261</td>
                <td class="leech_td">808</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/35015898/The-Legend-of-Tarzan-2016-720p-BrRip-x264-FGX" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 35015898 - The Legend of Tarzan 2016 720p BrRip x264 - FGX" href="/torrent/35015898/The-Legend-of-Tarzan-2016-720p-BrRip-x264-FGX"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - FGX</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:ec756cd3d07985fe152ec56e625baa647622d191&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - FGX" href="magnet:?xt=urn:btih:ec756cd3d07985fe152ec56e625baa647622d191&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">757.1 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-15</td>
                <td class="seed_td">19035</td>
                <td class="leech_td">2640</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34904450/The-Legend-of-Tarzan-2016-720p-BrRip-x264-RARBG" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34904450 - The Legend of Tarzan 2016 720p BrRip x264 - RARBG" href="/torrent/34904450/The-Legend-of-Tarzan-2016-720p-BrRip-x264-RARBG"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - RARBG</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:a046a7a7c6bec3c90e8537acb6c56844741aa8c4&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - RARBG" href="magnet:?xt=urn:btih:a046a7a7c6bec3c90e8537acb6c56844741aa8c4&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-02</td>
                <td class="seed_td">14587</td>
                <td class="leech_td">670</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/35005896/The-Legend-of-Tarzan-2016-720p-BrRip-x264-WoLF" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 35005896 - The Legend of Tarzan 2016 720p BrRip x264 - WoLF" href="/torrent/35005896/The-Legend-of-Tarzan-2016-720p-BrRip-x264-WoLF"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - WoLF</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:c40c452c4d8bba243d4a6f2d7eddde9341c92046&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - WoLF" href="magnet:?xt=urn:btih:c40c452c4d8bba243d4a6f2d7eddde9341c92046&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">767.93 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-14</td>
                <td class="seed_td">13246</td>
                <td class="leech_td">1480</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34875107/The-Legend-of-Tarzan-2016-720p-BrRip-x264-TiTAN" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34875107 - The Legend of Tarzan 2016 720p BrRip x264 - TiTAN" href="/torrent/34875107/The-Legend-of-Tarzan-2016-720p-BrRip-x264-TiTAN"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - TiTAN</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:ded3ea0a2dc9823944544ba1c8da20fdcf1d6b90&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - TiTAN" href="magnet:?xt=urn:btih:ded3ea0a2dc9823944544ba1c8da20fdcf1d6b90&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-08-30</td>
                <td class="seed_td">13000</td>
                <td class="leech_td">842</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/35010441/The-Legend-of-Tarzan-2016-720p-BrRip-x264-DONE" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 35010441 - The Legend of Tarzan 2016 720p BrRip x264 - DONE" href="/torrent/35010441/The-Legend-of-Tarzan-2016-720p-BrRip-x264-DONE"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - DONE</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:2ce38449d31bf9c9cf5dc3b627167532a9cf900f&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - DONE" href="magnet:?xt=urn:btih:2ce38449d31bf9c9cf5dc3b627167532a9cf900f&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">757.84 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-14</td>
                <td class="seed_td">12701</td>
                <td class="leech_td">1542</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34978360/The-Legend-of-Tarzan-2016-720p-BrRip-x264-ARROW" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34978360 - The Legend of Tarzan 2016 720p BrRip x264 - ARROW" href="/torrent/34978360/The-Legend-of-Tarzan-2016-720p-BrRip-x264-ARROW"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - ARROW</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:fa4ebd194d9978ddae2c81dea9585370f16c23b7&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - ARROW" href="magnet:?xt=urn:btih:fa4ebd194d9978ddae2c81dea9585370f16c23b7&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-10</td>
                <td class="seed_td">11582</td>
                <td class="leech_td">528</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34875594/The-Legend-of-Tarzan-2016-720p-BrRip-x264-YIFY" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34875594 - The Legend of Tarzan 2016 720p BrRip x264 - YIFY" href="/torrent/34875594/The-Legend-of-Tarzan-2016-720p-BrRip-x264-YIFY"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - YIFY</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:80afa36bb665fcebefa228b9d69bdca4e8c283ff&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - YIFY" href="magnet:?xt=urn:btih:80afa36bb665fcebefa228b9d69bdca4e8c283ff&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-08-30</td>
                <td class="seed_td">11006</td>
                <td class="leech_td">629</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/35011053/The-Legend-of-Tarzan-2016-720p-BrRip-x264-CFG" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 35011053 - The Legend of Tarzan 2016 720p BrRip x264 - CFG" href="/torrent/35011053/The-Legend-of-Tarzan-2016-720p-BrRip-x264-CFG"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - CFG</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:962d22bc7ab7d12e51afeee829b84eaa8d832fa8&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - CFG" href="magnet:?xt=urn:btih:962d22bc7ab7d12e51afeee829b84eaa8d832fa8&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">757.84 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-15</td>
                <td class="seed_td">10437</td>
                <td class="leech_td">1284</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34884180/The-Legend-of-Tarzan-2016-720p-BrRip-x264-CtrlHD" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34884180 - The Legend of Tarzan 2016 720p BrRip x264 - CtrlHD" href="/torrent/34884180/The-Legend-of-Tarzan-2016-720p-BrRip-x264-CtrlHD"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - CtrlHD</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:da13f888263dfa8c421daa185c4e59f5083b8755&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - CtrlHD" href="magnet:?xt=urn:btih:da13f888263dfa8c421daa185c4e59f5083b8755&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-08-31</td>
                <td class="seed_td">9121</td>
                <td class="leech_td">497</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/35004108/The-Legend-of-Tarzan-2016-720p-BrRip-x264-GK" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 35004108 - The Legend of Tarzan 2016 720p BrRip x264 - GK" href="/torrent/35004108/The-Legend-of-Tarzan-2016-720p-BrRip-x264-GK"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - GK</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:4271de2a73bc1c95364b24da280d949291bd2e2a&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - GK" href="magnet:?xt=urn:btih:4271de2a73bc1c95364b24da280d949291bd2e2a&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">767.93 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-13</td>
                <td class="seed_td">8895</td>
                <td class="leech_td">1370</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34975663/The-Legend-of-Tarzan-2016-720p-BrRip-x264-2HD" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34975663 - The Legend of Tarzan 2016 720p BrRip x264 - 2HD" href="/torrent/34975663/The-Legend-of-Tarzan-2016-720p-BrRip-x264-2HD"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - 2HD</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:81699bed8066f8352c49b1944f2a3b743db2fab5&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - 2HD" href="magnet:?xt=urn:btih:81699bed8066f8352c49b1944f2a3b743db2fab5&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-09</td>
                <td class="seed_td">8644</td>
                <td class="leech_td">99</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34965443/The-Legend-of-Tarzan-2016-720p-BrRip-x264-DIMENSION" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34965443 - The Legend of Tarzan 2016 720p BrRip x264 - DIMENSION" href="/torrent/34965443/The-Legend-of-Tarzan-2016-720p-BrRip-x264-DIMENSION"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - DIMENSION</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:a8fc8e366ac61686ffef500302042bfbb9513953&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - DIMENSION" href="magnet:?xt=urn:btih:a8fc8e366ac61686ffef500302042bfbb9513953&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-08</td>
                <td class="seed_td">8602</td>
                <td class="leech_td">62</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34902669/The-Legend-of-Tarzan-2016-720p-BrRip-x264-LEGi0N" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34902669 - The Legend of Tarzan 2016 720p BrRip x264 - LEGi0N" href="/torrent/34902669/The-Legend-of-Tarzan-2016-720p-BrRip-x264-LEGi0N"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - LEGi0N</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:a80a5aa1704d0fd00b832cd99579274ad18be94a&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - LEGi0N" href="magnet:?xt=urn:btih:a80a5aa1704d0fd00b832cd99579274ad18be94a&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-01</td>
                <td class="seed_td">7087</td>
                <td class="leech_td">418</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34951893/The-Legend-of-Tarzan-2016-720p-BrRip-x264-KILLERS" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34951893 - The Legend of Tarzan 2016 720p BrRip x264 - KILLERS" href="/torrent/34951893/The-Legend-of-Tarzan-2016-720p-BrRip-x264-KILLERS"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - KILLERS</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:1b602ae02ee9c8e4d73f92f3ba079aee9ac9514d&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - KILLERS" href="magnet:?xt=urn:btih:1b602ae02ee9c8e4d73f92f3ba079aee9ac9514d&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-06</td>
                <td class="seed_td">6632</td>
                <td class="leech_td">340</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34983676/The-Legend-of-Tarzan-2016-720p-BrRip-x264-LOL" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34983676 - The Legend of Tarzan 2016 720p BrRip x264 - LOL" href="/torrent/34983676/The-Legend-of-Tarzan-2016-720p-BrRip-x264-LOL"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - LOL</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:d4d9f942b546c0a5e99fc02a9126f840a97bfab7&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - LOL" href="magnet:?xt=urn:btih:d4d9f942b546c0a5e99fc02a9126f840a97bfab7&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-09-10</td>
                <td class="seed_td">6083</td>
                <td class="leech_td">49</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34881208/The-Legend-of-Tarzan-2016-720p-BrRip-x264-ASAP" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34881208 - The Legend of Tarzan 2016 720p BrRip x264 - ASAP" href="/torrent/34881208/The-Legend-of-Tarzan-2016-720p-BrRip-x264-ASAP"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - ASAP</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:77cfa8aab7052cef9fe24e695c15533de2d47650&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - ASAP" href="magnet:?xt=urn:btih:77cfa8aab7052cef9fe24e695c15533de2d47650&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-08-30</td>
                <td class="seed_td">5927</td>
                <td class="leech_td">263</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-other/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Other Torrents" href="http://btjunkie.eu/video/type-other/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Other)</span></a></td><td data-href="/torrent/34222568/The-Legend-of-Tarzan-2016-HD-TS-x264-CPG" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34222568 - The Legend of Tarzan 2016 HD-TS x264-CPG" href="/torrent/34222568/The-Legend-of-Tarzan-2016-HD-TS-x264-CPG"><h2>The Legend of <strong>Tarzan 2016</strong> HD-TS x264-CPG</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:C2FADAB194E430B155B5F28941145578069FA43B&tr=udp://9.rarbg.me:2710/announce&tr=udp://9.rarbg.com:2710/announce&tr=udp://coppersurfer.tk:6969/announce&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.openbittorrent.com:80/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=http://tracker.trackerfix.com/announce&tr=http://exodus.desync.com:6969/announce&tr=udp://explodie.org:6969/announce&tr=udp://11.rarbg.com:80/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://tracker.aletorrenty.pl:2710/announce&tr=udp://eddie4.nl:6969/announce&tr=udp://thetracker.org:80/announce&tr=udp://glotorrents.pw:6969/announce&tr=udp://p4p.arenabg.ch:1337/announce&tr=udp://p4p.arenabg.com:1337/announce&tr=udp://9.rarbg.to:2710/announce&tr=udp://torrent.gresille.org:80/announce&tr=udp://tracker.opentrackr.org:1337/announce&tr=udp://tracker.piratepublic.com:1337/announce&tr=udp://tracker.sktorrent.net:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 HD-TS x264-CPG" href="magnet:?xt=urn:btih:C2FADAB194E430B155B5F28941145578069FA43B&tr=udp://9.rarbg.me:2710/announce&tr=udp://9.rarbg.com:2710/announce&tr=udp://coppersurfer.tk:6969/announce&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.openbittorrent.com:80/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=http://tracker.trackerfix.com/announce&tr=http://exodus.desync.com:6969/announce&tr=udp://explodie.org:6969/announce&tr=udp://11.rarbg.com:80/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://tracker.aletorrenty.pl:2710/announce&tr=udp://eddie4.nl:6969/announce&tr=udp://thetracker.org:80/announce&tr=udp://glotorrents.pw:6969/announce&tr=udp://p4p.arenabg.ch:1337/announce&tr=udp://p4p.arenabg.com:1337/announce&tr=udp://9.rarbg.to:2710/announce&tr=udp://torrent.gresille.org:80/announce&tr=udp://tracker.opentrackr.org:1337/announce&tr=udp://tracker.piratepublic.com:1337/announce&tr=udp://tracker.sktorrent.net:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">1.75 GB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-07-08</td>
                <td class="seed_td">5563</td>
                <td class="leech_td">2043</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34888581/The-Legend-of-Tarzan-2016-720p-BrRip-x264-KILLERS" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34888581 - The Legend of Tarzan 2016 720p BrRip x264 - KILLERS" href="/torrent/34888581/The-Legend-of-Tarzan-2016-720p-BrRip-x264-KILLERS"><h2>The Legend of <strong>Tarzan 2016</strong> 720p BrRip x264 - KILLERS</h2></a></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:75756e5ea70960e0e0c040062cc7b94ffcf31af1&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The Legend of Tarzan 2016 720p BrRip x264 - KILLERS" href="magnet:?xt=urn:btih:75756e5ea70960e0e0c040062cc7b94ffcf31af1&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=udp://exodus.desync.com:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://zer0day.ch:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">704.03 MB</td>
                <td class="files_td">3</td>
                <td class="date_td">2016-08-31</td>
                <td class="seed_td">5501</td>
                <td class="leech_td">315</td>
                <td class="health_td">100%</td>
            </tr>
                    <tr>
            <td data-href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016" class="type_td"><a class="p2" title="Download Movies Torrents" href="http://btjunkie.eu/video/type-movies/by-seed/asc/page1/tarzan 2016"/><span class="td-category-label">Video</span><span class="td-type-label">(Movies)</span></a></td><td data-href="/torrent/34407033/The-Legend-of-Tarzan-2016-HC-HDRip-XviD-AC3-EVO" class="title_td"><div class="title_td_sublayer"><a class="p2" title="View details for 34407033 - The.Legend.of.Tarzan.2016.HC.HDRip.XviD.AC3-EVO" href="/torrent/34407033/The-Legend-of-Tarzan-2016-HC-HDRip-XviD-AC3-EVO"><h2>The.Legend.of.<strong>Tarzan.2016</strong>.HC.HDRip.XviD.AC3-EVO</h2></a><span class="icon good" title="Good"></span></div></td>                </td>
                <td data-href="magnet:?xt=urn:btih:C10937099FFFB9BEA1057F71F479298B231189E7&tr=udp://9.rarbg.me:2710/announce&tr=udp://coppersurfer.tk:6969/announce&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.openbittorrent.com:80/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=http://tracker.tfile.me/announce&tr=http://bigfoot1942.sektori.org:6969/announce&tr=http://tracker.trackerfix.com/announce&tr=http://explodie.org:6969/announce&tr=udp://explodie.org:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://tracker.aletorrenty.pl:2710/announce&tr=udp://eddie4.nl:6969/announce&tr=udp://tracker.pomf.se:80/announce&tr=udp://thetracker.org:80/announce&tr=udp://glotorrents.pw:6969/announce&tr=udp://tracker4.piratux.com:6969/announce&tr=udp://tracker.blackunicorn.xyz:6969/announce&tr=udp://p4p.arenabg.ch:1337/announce&tr=udp://9.rarbg.to:2710/announce&tr=udp://torrent.gresille.org:80/announce&tr=udp://tracker.opentrackr.org:1337/announce&tr=udp://tracker.internetwarriors.net:1337/announce&tr=udp://tracker.piratepublic.com:1337/announce&tr=udp://tracker.sktorrent.net:6969/announce&tr=http://www.opentrackr.org/announce&tr=http://opentrackr.org/announce&tr=udp://zer0day.ch:1337/announce&tr=http://opentrackr.org:1337/announce" class="magnet_td">
                    <div class="torrent_options">
                        <a role="btn" title="Download Magnet The.Legend.of.Tarzan.2016.HC.HDRip.XviD.AC3-EVO" href="magnet:?xt=urn:btih:C10937099FFFB9BEA1057F71F479298B231189E7&tr=udp://9.rarbg.me:2710/announce&tr=udp://coppersurfer.tk:6969/announce&tr=udp://open.demonii.com:1337/announce&tr=udp://tracker.openbittorrent.com:80/announce&tr=udp://tracker.coppersurfer.tk:6969/announce&tr=http://tracker.tfile.me/announce&tr=http://bigfoot1942.sektori.org:6969/announce&tr=http://tracker.trackerfix.com/announce&tr=http://explodie.org:6969/announce&tr=udp://explodie.org:6969/announce&tr=udp://tracker.leechers-paradise.org:6969/announce&tr=udp://tracker.aletorrenty.pl:2710/announce&tr=udp://eddie4.nl:6969/announce&tr=udp://tracker.pomf.se:80/announce&tr=udp://thetracker.org:80/announce&tr=udp://glotorrents.pw:6969/announce&tr=udp://tracker4.piratux.com:6969/announce&tr=udp://tracker.blackunicorn.xyz:6969/announce&tr=udp://p4p.arenabg.ch:1337/announce&tr=udp://9.rarbg.to:2710/announce&tr=udp://torrent.gresille.org:80/announce&tr=udp://tracker.opentrackr.org:1337/announce&tr=udp://tracker.internetwarriors.net:1337/announce&tr=udp://tracker.piratepublic.com:1337/announce&tr=udp://tracker.sktorrent.net:6969/announce&tr=http://www.opentrackr.org/announce&tr=http://opentrackr.org/announce&tr=udp://zer0day.ch:1337/announce&tr=http://opentrackr.org:1337/announce">
                           <span class="icon magnet-blue"></span>
                        </a>
                    </div>
                </td>
                <td class="size_td">1.39 GB</td>
                <td class="files_td">4</td>
                <td class="date_td">2016-08-03</td>
                <td class="seed_td">5230</td>
                <td class="leech_td">2244</td>
                <td class="health_td">100%</td>
            </tr>
        </tbody></table><form id="pagination"><a class="selected"title="Page 1" href="http://btjunkie.eu/all/type-all/by-seed/desc/page1/tarzan 2016">1</a><a title="Page 2" href="http://btjunkie.eu/all/type-all/by-seed/desc/page2/tarzan 2016">2</a><a title="Page 3" href="http://btjunkie.eu/all/type-all/by-seed/desc/page3/tarzan 2016">3</a><a title="Page 4" href="http://btjunkie.eu/all/type-all/by-seed/desc/page4/tarzan 2016">4</a><a title="Page 5" href="http://btjunkie.eu/all/type-all/by-seed/desc/page5/tarzan 2016">5</a><a title="Next" href="http://btjunkie.eu/all/type-all/by-seed/desc/page2/tarzan 2016">></a><a title="Last" href="http://btjunkie.eu/all/type-all/by-seed/desc/page55/tarzan 2016">Last</a></form></div></section><!--<img src="/img/up_arrow.png" height="40" alt="top" id="scroll_top" />-->
<button class="icon" id="scroll_top"></button>
<div class="mario-loader"></div>
<footer id="main_footer">
    <!--SHARE BOX-->
    <div id="share_box">
        <a title="Like us on Facebook!" id="fb_btn" class="icon social" href="https://www.facebook.com/pages/BTJunkieeu-torrent-search-engine/809642329068743" target="_blank"></a>
        <a title="Follow us on Twitter!" id="twitter_btn" class="icon social" href="https://twitter.com/BTJunkie_eu" target="_blank"></a>
    </div>
    <a title="Contact Us" href="/contact">Contact Us</a>
        <span id="indexed-torrents-counter">Indexing <span id="indexed-torrents-cnt">32 753 458</span> active torrents</span>    <a title="BtJunkie Home" href="/">

                    <img id="footLogo" src="/img/logo-long2.png" alt="btjunkey" height="30" style="position: absolute; top: 10px; left: 10px;"/>
            </a>
</footer>
<div id="user_form_wrap" data-pop='{"popper": "#user_form_btn", "clas": "expanded"}' class="pop ">
    <div id="user_form_box">
        <form id="user_form" method="post" action="/all/type-all/by-seed/desc/page1/tarzan%202016">
            <h3 id="user-form-title" class="visible">
            Login            </h3>
                        <div id="login" class="form-section clearfix visible">
                <div class="input-box">
                    <label for="username">
                        <span class="icon reg-user"></span>
                    </label>
                    <input type="text" id="username" name="username" pattern="[a-zA-Z0-9_-]{3,20}" required="required" title='3-20 symbols containing only "a-z", "A-Z", "_" and "-"' placeholder="Username"/>
                </div>
                <div class="input-box">
                    <label for="pass">
                        <span class="icon reg-pass"></span>
                    </label>
                    <input type="password" id="pass" name="pass" placeholder="Password"
                    pattern="[a-zA-Z0-9_-]{4,20}" required="required" title='4-20 symbols containing only "a-z", "A-Z", "_" and "-"' />
                </div>
            </div>

            <div id="register" class="form-section clearfix ">
                <div class="input-box">
                    <label for="repeatpass">
                        <span class="icon reg-pass"></span>
                    </label>
                    <input type="password" id="repeatpass" name="repeatpass" placeholder="Confirm password"/>
                </div>
                <div class="input-box">
                    <label for="email">
                        <span class="icon reg-email"></span>
                    </label>
                    <input type="email" name="email" id="email" placeholder="Email"/>
                </div>
            </div>

            <div id="recovery" class="form-section clearfix ">
                <div class="input-box">
                    <label for="email_recovery">
                        <span class="icon reg-email"></span>
                    </label>
                    <input type="email" name="email_recovery" id="email_recovery" placeholder="Email"/>
                </div>
            </div>

            <input type="submit" id="submit_user_form" name="submit" value="Login"/>
            <button id="switch-login" class="switch-user-form ">Back to login.</button>
            <button id="switch-forgot" class="switch-user-form visible">Forgot your password?</button>
            <button id="switch-register" class="switch-user-form visible">Don't have an account? Click here.</button>
        </form>
    </div>
    <button id="hide_user_form" class="icon"></button>
</div>
<!-- CONFIRM BOX -->
<div class="confirm cc-fixed bs-bb-all pop">
    <div class="conf-titlebar">
        <span class="conf-title">Account deleting</span>
        <button class="conf-close">x</button>
    </div>
    <div class="conf-container">
        <p class="conf-content">Are you sure you want to delete your account?</p>
        <p class="conf-warning">WARNING: This action cannot be undone!!!</p>
    </div>
    <div class="conf-footer">
        <button class="conf-cancel-btn conf-btn alert-btn">OK</button>
        <button class="conf-confirm-btn conf-btn confirm-btn">OK</button>
        <button class="conf-cancel-btn conf-btn confirm-btn">Cancel</button>
    </div>
</div>


    <script type="text/javascript" src="/js/libs/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="/js/jqcloud-1.0.4.min.js"></script>
    <script id="script1" type="text/javascript" src="/js/hammer.min.js"></script>
    <script id="script1" type="text/javascript" src="/js/jquery.hammer.js"></script>
    <script id="script1" type="text/javascript" src="/js/jquery-extend.js"></script>
    <script id="script1" type="text/javascript" src="/js/html2canvas.js"></script>
    <script id="script1" type="text/javascript" src="/js/rb.js"></script>
    <script id="script1" type="text/javascript" src="/js/script2.js"></script>
    <script type="text/javascript" src="/js/functions.js"></script>


    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-58485485-1', 'auto'); ga('send', 'pageview');
    </script>

    </body>
</html>

'''

from ehp import Html

dom = Html().feed(html)

row_search = "dom." + "find_all('tr', start=2)"
name_search = "item('h2')"
info_hash_search = ""
magnet_search = "item(tag='td', select=('class', 'magnet_td'), attribute='data-href')"
size_search = "item(tag='td', select=('class', 'size_td'))"
seeds_search = "item(tag='td', select=('class', 'seed_td'))"
peers_search = "item(tag='td', select=('class', 'leech_td'))"
if dom is not None:
    for item in eval(row_search):
        if item is not None:
            name = eval(name_search)  # name
            magnet = eval(magnet_search) if len(magnet_search) > 0 else ""  # magnet
            info_hash = eval(info_hash_search) if len(info_hash_search) > 0 else ""  # size
            size = eval(size_search) if len(size_search) > 0 else ""  # size
            seeds = eval(seeds_search) if len(seeds_search) > 0 else ""  # seeds
            peers = eval(peers_search) if len(peers_search) > 0 else ""  # peers
            print (name, info_hash, magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers