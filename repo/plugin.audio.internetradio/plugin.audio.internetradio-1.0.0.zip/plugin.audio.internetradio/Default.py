# -*- coding: utf-8 -*-

#import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time
import sys
#import xbmc, 
import xbmcgui, xbmcplugin, xbmcaddon
#import urllib
import os


##General vars
__plugin__ = "Israel Radio"
__author__ = "dhead"
__credits__ = ""
__version__ = "1.4.20111225"
__USERAGENT__ = 'XBMC dhead'
__XBMC_Revision__ = ""
__AddonID__ = 'plugin.audio.internetradio'

Addon = xbmcaddon.Addon(__AddonID__)

## Script location
HOME_DIR = Addon.getAddonInfo('path').decode("utf-8")
PICS_DIR = os.path.join(HOME_DIR, 'resources', 'media')
STATIONS_DIR = os.path.join(HOME_DIR, 'resources', 'stations')

STATIONS = \
	('88fm ', "88fm"),\
	('91fm ', "91fm - Lev Ha-Medina"),\
	('100fm - RADIUS', "100fm - Radius"),\
	('101fm - Radio jerusalem', "101fm.Radio.Jerusalem"),\
	('102fm - Radio Tel aviv', "102fm"),\
	('103fm - radio lelo hafsaka', "103fm"),\
	('99fm - eco', "99fm"),\
	('channel 7', "Aruts 7"),\
	('Kol Hamusica ', "Kol Hamusica"),\
	('Reshet Bet', "Reshet Bet"),\
	('Reshet Gimel', "Reshet Gimel"),\
	('Reshet Moreshet', "Reshet Moreshet"),\
	('Galgalaz', "Galgalaz"),\
	('Galaz', "Galaz"),\
	('RadioDance', "radiodance"),\
	('ClickFM', "clickfm"),\
	('Click2Dance', "click2dance"),\
	('Click Hiphop', "ClickHipHop"),\
	('Click Cafe', "ClickCafe"),\
	('Click2Love - internet station', "Click2Love"),\
	('Click Israel', "Click Israel"),\
	('109FM', "109fm"),\
	('radio beat', "radiobeat"),\
	('107.5 Radio Haifa', "1075RadioHaifa"),\
	('96fm Radio Kol Rega', "96fmKolRega"),\
	('106.2FM', "106.2FM"),\
	
		
	  

#handle = int(sys.argv[1])

def show_root_menu():
	for col in STATIONS:
		name = col[0]
		url = os.path.join(STATIONS_DIR, "{0}.strm".format(col[1])) 
		tmb = os.path.join(PICS_DIR, "{0}.png".format(col[1]))
		item = xbmcgui.ListItem(name, iconImage = 'icon.png' , thumbnailImage = tmb)
		item.setProperty('IsPlayable', 'true')
		item.setProperty("IsLive", "true")
		item.setInfo(type = 'audio', infoLabels = {'title' : name})
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, item)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


if not sys.argv[2]:
    ok = show_root_menu()
