# -*- coding: utf-8 -*-

#import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time
import sys
import xbmc, xbmcgui, xbmcplugin
import urllib
import os


##General vars
__plugin__ = "Israel TV"
__author__ = "ilancoll"
__credits__ = ""
__version__ = "1.4.20111225"
__USERAGENT__ = 'XBMC dhead'
__XBMC_Revision__ = ""

## Script location
HOME_DIR=os.getcwd()
HOME_DIR=HOME_DIR+"\\"
PICS_DIR=HOME_DIR+"resources\\media\\"
STATIONS_DIR=HOME_DIR+"resources\\stations\\"

STATIONS = \
	('nana10', STATIONS_DIR+"nana10.strm" , "nana10.png"),\
	('arutz 1', STATIONS_DIR+"11.strm" , "11.png"),\
	('arutz haknesset', STATIONS_DIR+"knessetlive.strm" , "knessetlive.png"),\
	('I24 news', STATIONS_DIR+"i24.strm" , "i24.png"),\
	('reshet arutz2', STATIONS_DIR+"reshet.strm" , "reshet.png"),\
	('Vevo Tv CH1 (music)', STATIONS_DIR+"vevoch1.strm" , "vevoch1.png"),\
	('Vevo Tv CH2 (music)', STATIONS_DIR+"vevoch2.strm" , "vevoch2.png"),\
	('Fashion Tv', STATIONS_DIR+"FashionTv.strm" , "FashionTv.png"),\
	('Radio 105 (music)', STATIONS_DIR+"Radio105NetworkTV.strm" , "Radio105NetworkTV.png"),\
	('Radio Montecarlo (music)', STATIONS_DIR+"RadioMontecarloTV.strm" , "RadioMontecarloTV.png"),\
	('Virgin (music)', STATIONS_DIR+"Virgin.strm" , "Virgin.png"),\
	('VH1 classic (music)', STATIONS_DIR+"vh1-classic.strm" , "vh1-classic.png"),\
	('VH1 (music)', STATIONS_DIR+"vh1.strm" , "vh1.png"),\
	('Mtv Dance (music)', STATIONS_DIR+"mtvdance.strm" , "mtvdance.png"),\
	('Mtv Hits (music)', STATIONS_DIR+"mtvhits.strm" , "mtvhits.png"),\
	('Heart TV(music)', STATIONS_DIR+"heartTV.strm" , "heartTV.png"),\
	('24 music', STATIONS_DIR+"24music.strm" , "24music.png"),\
	('E4', STATIONS_DIR+"E4HD.strm" , "E4HD.png"),\
	('Animal Planet', STATIONS_DIR+"AnimalPlanet.strm" , "AnimalPlanet.png"),\
	('Discovery Channel ', STATIONS_DIR+"DiscoveryCh.strm" , "DiscoveryCh.png"),\
	('test', STATIONS_DIR+"test.strm" , "test.png"),\
	
	


handle = int(sys.argv[1])

def show_root_menu():
	for col in STATIONS:
		name = col[0]
		url = col[1]
		tmb = col[2]
		item = xbmcgui.ListItem(name, iconImage = 'icon.png' , thumbnailImage = PICS_DIR+tmb)
		item.setProperty('IsPlayable', 'true')
		item.setProperty("IsLive", "true")
		item.setInfo(type = 'audio', infoLabels = {'title' : name})
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, item)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


if not sys.argv[2]:
    ok = show_root_menu()
