Introduction
===================
The provider use the URL address for each subject:  General, Movies, TV Shows, Seasons and Animes.

The url has reserved word QUERY which will be replace with each query and the spaces will replaced by separator characters.

If you want to add some word to the search, you can use the queries. 
{title}  => Title in english
{year}	 => Year
{title:ru}  => Title in russian
{title:fr}  => Title in french
{season}  => Season
{season:n}  => Season with format in n digits
{episode}  => Episode
{episode:n}  => Episode with format in n digits
s{season:2}e{episode:2}  =>  S02e02
s{season}e{episode}  =>  S2e2
s{season}e{episode:3}  => s2e002

For advanced queries:

{title} swedish

It will search for the title in english plus the word swedish

Filtering
===================
This helps to parse the results according keywords.

The accepted keywords mean that the title needs to have any or all of those keywords to be accepted.
The blocked keywords mean that the title will be rejects if it has any or all of those keywords.

The keywords need to be inside curly brackets, ie:  {720p}

If you have several keywords:
{720p}{hdtv}{4k}  It means 720p OR HDTV or 4K.

If you have several words in the same curly brackets
{720p hdtv}  It means 720p AND HDTV.

It could possible different combination.

No keywords means the option is disabled.

The keywords are case case insensitive.

The keywords search any match, starting, in the middle or finishing, ie:  {cam}
it will be positive for words like webcam camera webcaming

If you want only the word, you need to use ? character, ie: 
{?cam} only starting with cam
{?cam?} only the word cam
{cam?} only finishing with cam

By default the provider always check that the name of the result has all the words of the title.  However, that option can be disabled from the settings.

Installation
============
Please, visit this link: https://github.com/mancuniancol/repository.magnetic
