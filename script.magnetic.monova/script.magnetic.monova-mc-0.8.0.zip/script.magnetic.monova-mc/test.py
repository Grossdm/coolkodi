# coding: utf-8
__author__ = 'mancuniancol'

html = '''


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="description" content="Search &  Download tarzan 2016 for free"/>
<meta name="author" content="monova.org"/>
<link rel="shortcut icon" href="data:image/png;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAD18/EOnYJppXVUNPdxUDD/cE4u/25MK/9sSin/a0gn/2lGJf9nRCP/ZkIh/2RAHv9iPhz/ZUMg95uBZ6X18/EOnoVsoYdvWf+Nemj/iHVi/4RvXP+BbFr/e2RQ/3ZfSv9xWkT/bVZB/2hPOP9kSjL/X0Qs/1o/Jv9ZOx//nIJpo3FNKfWNb1H/qZJ7/6mSfP9+XT3/dlc6/6iRe/+pkXv/qZN8/25NLv92VDP/qZJ8/6mSe/+eg2r/Xj4f/2VDIfd2UzL/s56K////////////moBn/4VnSv////////////////+Qc1j/g2VI////////////4trS/2FBI/9iPh3/fl4//6SMdf///////////5+Gbf+dhGv/////////////////vaya/3tYN////////////+Lb0/9kRSf/ZEEf/4JjRv+cgmn///////////+mjnf/u6mX/////////////////+zn4v90Tyv////////////k3db/Z0gr/2ZDI
    v+EZkn/l3xi////////////rpmE/9vSyP//////////////////////i2xN////////////5+Ha/2pLLv9oRST/h2lM/5N3Xf///////////7qnlf/5+Pb//////+jh2/////7//////6+Zhf/+/v7//////+vm4P9sTTD/aUcm/4lsT/+QdFn////////////d1Mv////////////Ftqf/6+bh///////OwbT//fz8///////v6+b/bk8y/2tJKf+Mb1P/kXZc//z7+v///////Pz7////////////qpR+/7+unf//////7urm//v6+f//////8/Dt/3BRM/9tSyv/jnJW/5mAZ//08e7//////////////////////5B0Wf+TeF3///////////////7///////j29P9yUjT/b04u/5F1Wf+jjXf/6uXf//////////////////f18/+FaU3/hWlO//Ds6P/////////////////8+/r/dVU3/3FQMP+TeF3/rpuI/+La0v/////////////////YzsT/mIFs/56Mev/BsKD//////////////////v79/3laPP9zUjL/lHhc87qqmv+qlH7/v66d/7+unf+/rp3/noRr/6ubi/+0qZ7/jW9
    R/7+unv+/rp3/v66d/8Cvnv95WTv/eFc49aOLc5zDtab/yb2x/8S3qv+/saT/uaqc/7OjlP/Bt67/vbOp/6eWhv+ei3n/mYVy/5R/bP+Qemb/g2lQ/6CHb5/39vQKo4tzm45xU/CNcFP6i25Q+olrTvqHaUv6hWZI+oJkRfqBYkL6f19B+n1dPvp7Wjv6fFs88KGIcJz49vQKgAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAEAAA=="/>
<meta name="msvalidate.01" content="EC6001F9520C26011A33D9D4CACB2A41"/>
<link rel="alternate" hreflang="x-default" href="//www.monova.org/search?term=tarzan+2016">
<link rel="alternate" hreflang="it" href="//it.monova.org/search?term=tarzan+2016"/>
<link rel="alternate" hreflang="ru" href="//ru.monova.org/search?term=tarzan+2016"/>
<title>Search Results for "tarzan 2016" - Torrent Search</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="//monova.org/css/materialize.css" rel="stylesheet"/>
<link href="//monova.org/css/style-v2.css?v=0.8" rel="stylesheet"/>
<script>
        var base_uri = "//monova.org/";
        var user_login = false;
        var is_win_ios = true;
        var is_mobile = false;
        var adblock = true;
    </script>
<script src="//monova.org/js/ads.js"></script>
<script>
        function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
        }

        function setCookie(name, value, options) {
            options = options || {};

            var expires = options.expires;

            if (typeof expires == "number" && expires) {
                var d = new Date();
                d.setTime(d.getTime() + expires * 1000);
                expires = options.expires = d;
            }
            if (expires && expires.toUTCString) {
                options.expires = expires.toUTCString();
            }

            value = encodeURIComponent(value);

            var updatedCookie = name + "=" + value;

            for (var propName in options) {
                updatedCookie += "; " + propName;
                var propValue = options[propName];
                if (propValue !== true) {
                    updatedCookie += "=" + propValue;
                }
            }
            document.cookie = updatedCookie;
        }

        if (adblock){
            if (getCookie('MOP_ADB') == undefined) {
                setCookie('MOP_ADB', '1', {path: '/'});
                location.reload();
            }
        } else {
            if (getCookie('MOP_ADB') != undefined){
                setCookie('MOP_ADB', '', {expires: -10});
                //location.reload();
            }
        }
        function vmjDMwnXlKSYURVsq(id){
            var name = '';
            if (id == 'EyKksJZVWHiRSnbXz') name = 'ad_big_download';
            if (id == 'wBWMzePLQJDjIklhvt') name = 'ad_big_magnet';
            if (id == 'LmWOgiGZeXoVKplPRrhA') name = 'ad_usenet_download_button';
            if (id == '') name = 'ad_small_right';
            if (id == '') name = 'ad_small_left';
            if (id == 'rlkQczwIitjVYsohApZ') name = 'ad_injected';
            if (id == 'KrpFxVsXfyBcJiaEHbWdUz') name = 'ad_usenet';
            if (id == 'avEyKljwesonQRbIAV') name = 'ad_sponsored';

            if (send_ga_events != undefined && send_ga_events)
                ga('send', 'event', 'ad_clicked', 'click', name);
        }
    </script>
</head>
<body role="document">
<img class="m-logo logo-background"/>
<header class="navbar-fixed">
<ul id="browse_dropdown" class="dropdown-content">
<ul class="dropdown-menu multi-column columns-2" role="menu">
<div class="nav-column">
<ul class="multi-column-dropdown">
<li><a href="//monova.org/adult"><i class="fa fa-venus-mars hidden-xs"></i>Adult</a></li>
<li><a href="//monova.org/audio"><i class="fa fa-music hidden-xs"></i>Audio</a></li>
<li><a href="//monova.org/books"><i class="fa fa-book hidden-xs"></i>Books</a></li>
<li><a href="//monova.org/games"><i class="fa fa-gamepad hidden-xs"></i>Games</a></li>
</div>
<div class="nav-column">
<ul class="multi-column-dropdown">
<li><a href="//monova.org/other"><i class="fa fa-list hidden-xs"></i>Others</a></li>
<li><a href="//monova.org/photos"><i class="fa fa-picture-o hidden-xs"></i>Photos</a></li>
<li><a href="//monova.org/software"><i class="fa fa-cog hidden-xs"></i>Software</a></li>
<li><a href="//monova.org/video"><i class="fa fa-video-camera hidden-xs"></i>Video</a></li>
</ul>
</div>
</ul>
</ul>
<ul id="language_dropdown" class="dropdown-content">
<li class="language">
<ul class="dropdown-menu">
<li><a data-lang="en" hreflang="en" href="//monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-us"></span>&nbsp;&nbsp;English</a></li>
<li><a data-lang="it" hreflang="it" href="//it.monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-it"></span>&nbsp;&nbsp;Italian</a></li>
<li><a data-lang="ru" hreflang="ru" href="//ru.monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-ru"></span>&nbsp;&nbsp;Russian</a></li>
</ul>
</li>
</ul>
<nav class="" role="navigation" style="background-color: #003E74 !important;">
<div class="nav-wrapper container-bt">
<form class="autocomplete-form" style="display: none" action="//monova.org/search">
<div class="input-field">
<input id="search" class="autocomplete" name="term" type="search" required placeholder="Search by name or hash..." autocomplete="off">
<label for="search"><i class="material-icons">search</i></label>
<i class="material-icons">close</i>
</div>
</form>
<div id="navigation-buttons">
<ul class="left hide-on-med-and-down">
<li class="waves-effect waves-light"><a href="//monova.org/"><i class="fa fa-home fa-lg"></i></a></li>

<li class="waves-effect waves-light"><a href="//monova.org/latest"><i class="fa fa-clock-o fa-lg"></i></a></li>
<li class="waves-effect waves-light" id="nav-search-button"><a href="#"><i class="fa fa-search fa-lg"></i></a></li>
</ul>
<ul class="right hide-on-med-and-down">
<li><a class="dropdown-button waves-effect waves-light" href="#!" data-activates="browse_dropdown"><i class="fa fa-list-ul fa-lg"></i>&nbsp;&nbsp;Browse</a></li>
<li><a href="#" class="lightbox_button" data-name="upload"><i class="fa fa-upload fa-lg"></i>&nbsp;&nbsp;<span class="hidden-sm">Upload</span></a></li>
<li><a class="lightbox_button" data-name="login" href="#!"><i class="fa fa-sign-in fa-lg"></i>&nbsp;&nbsp;<span class="hidden-sm">Login/Register</span></a></li>
<li>
<a href="#!" class="dropdown-button waves-effect waves-light" data-activates="language_dropdown">
<span class="flag-icon flag-icon-us"></span>
<span class="hidden-sm">&nbsp;EN</span>
</a>
</li>
</ul>
</div>
<ul id="nav-mobile" class="side-nav">
<li><a href="//monova.org/" class="waves-effect waves-light"><i class="fa fa-home fa-lg"></i>Home</a></li>
<li><a href="//monova.org/latest" class="waves-effect waves-light"><i class="fa fa-clock-o fa-lg"></i>Latest</a></li>

<li><a href="//monova.org/search" class="waves-effect waves-light"><i class="fa fa-search fa-lg"></i>Search</a></li>
<ul class="collapsible" data-collapsible="accordion">
<li>
<div class="collapsible-header"><i class="fa fa-list-ul fa-lg"></i>Browse</div>
<div class="collapsible-body">
<ul>
<li><a href="//monova.org/adult"><i class="fa fa-venus-mars fa-lg"></i>Adult</a></li>
<li><a href="//monova.org/audio"><i class="fa fa-music fa-lg"></i>Audio</a></li>
<li><a href="//monova.org/books"><i class="fa fa-book fa-lg"></i>Books</a></li>
<li><a href="//monova.org/games"><i class="fa fa-gamepad fa-lg"></i>Games</a></li>
<li><a href="//monova.org/other"><i class="fa fa-list fa-lg"></i>Other</a></li>
<li><a href="//monova.org/photos"><i class="fa fa-picture-o fa-lg"></i>Photos</a></li>
<li><a href="//monova.org/software"><i class="fa fa-cog fa-lg"></i>Software</a></li>
<li><a href="//monova.org/video"><i class="fa fa-video-camera fa-lg"></i>Video</a></li>
</ul>
</div>
</li>
</ul>
<li><a class="lightbox_button" data-name="login" href="#!"><i class="fa fa-sign-in fa-lg"></i><span>Login/Register</span></a></li>
<li><a class="lightbox_button" data-name="contact" href="#!"><i class="fa fa-envelope fa-lg"></i>Contact</a></li>
<ul class="collapsible" data-collapsible="accordion">
<li>
<div class="collapsible-header">
<span class="flag-icon flag-icon-us"></span>
<span class="hidden-sm">EN</span>
</div>
<div class="collapsible-body">
<ul class="language dropdown-menu">
<li><a data-lang="en" hreflang="en" href="//monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-us"></span>&nbsp;&nbsp;English</a></li>
<li><a data-lang="it" hreflang="it" href="//it.monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-it"></span>&nbsp;&nbsp;Italian</a></li>
<li><a data-lang="ru" hreflang="ru" href="//ru.monova.org/search?term=tarzan+2016"><span class="flag-icon flag-icon-ru"></span>&nbsp;&nbsp;Russian</a></li>
</ul>
</div>
</li>
</ul>
</ul>
<div id="nav-filters" class="side-nav right">
<div class="row" style="padding: 0 15px;">
<div class="col-md-12">
<form action="" method="get">
<input type="hidden" name="term" value="tarzan 2016">
<div class="filter-label">Show:</div>
<div class="input-field">
<select name="verified">
<option value="0" selected>All</option>
<option value="1">Verified</option>
</select>
</div>
<div class="filter-label">Sort By:</div>
<div class="input-field">
<select name="sort">
<option value="1" selected>Date</option>
<option value="4">Rating</option>
<option value="5">Size</option>
<option value="6">Peers</option>
</select>
</div>
<div class="filter-label">Category:</div>
<div class="input-field">
<select name="cat">
<option value="-1" selected>All</option>
<option value="6">Adult</option>
<option value="2">Audio</option>
<option value="3">Books</option>
<option value="4">Games</option>
<option value="7">Other</option>
<option value="8">Photos</option>
<option value="5">Software</option>
<option value="1">Video</option>
</select>
</div>
<div class="center-align">
<button type="submit" class="btn">Submit</button>
</div>
</form>
</div>
</div>
</div>
<a href="#" data-activates="nav-mobile" class="button-collapse" data-edge="left"><i class="material-icons">menu</i></a>
<a href="#" data-activates="nav-filters" class="button-collapse right hide-on-large-only" data-edge="right"><i class="fa fa-filter" style="font-size: 2.3rem;"></i></a>
</div>
</nav>
</header>
<script data-cfasync="false" type="text/javascript" src="//ruckusschroederraspberry.com/br7J7eyJyb3V0ZSI6ICJnZXRfanMiLCAic3RpZCI6ICIxMjIxMCIsICJkIjogInJ1Y2t1c3NjaHJvZWRlcnJhc3BiZXJyeS5jb20ifQ==1p7Tn"></script>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(w(){7 a=\'1X.1V.1R\';7 b=\'//1V.1R/1O/1U/1U.2c\';7 c=\'2b\';7 d=3;7 e=1;7 f=C;7 g=C;7 h=F;7 i={28:\'2d\',26:\'2f\',20:\'1\',1q:\'11\',21:24(9.1i.L),23:D.2G};7 j=w(a,b,c){7 d="";v(c){7 e=1M 1T();e.2v(e.1E()+(c*2w*2A));d="; 2F="+e.2C()}G d="";9.1K=a+"="+b+d+"; 1O=/"};7 k=w(a){7 b=a+"=";7 c=9.1K.2l(\';\');O(7 d=0;d<c.B;d++){7 e=c[d];1I(e.y(0)==\' \')e=e.1H(1,e.B);v(e.1o(b)==0)x e.1H(b.B,e.B)}x F};7 l=w(a){7 b=w(a,b){1I(a.1P){a=a.1P;v(a.1g!=1y&&a.1g.1k()===b)x a}x F};7 e=(2i!==D)?9.2m:D.1i.L;7 l=n(i);v(a.1f.1g.1k()==\'a\'){e=a.1f.L;a.1W()}G{7 o=b(a.1f,\'a\');v(o!=F){e=o.L;a.1W()}}7 p=m().1k();7 q=k(c)==F?0:1u(k(c));g=Q;v(f)9.J.19(h);j(c,q+1,d);v(p.1o(\'1B\')!=-1){7 r=9.Z(\'a\');r.L=e;7 s=9.2p(\'2o\');s.2r(\'1m\',Q,Q,D,0,0,0,0,0,C,C,C,C,Q?1:0,F);r.2s(s)}G D.2n(e,\'\');D.1F.1i.L=l};7 m=w(){7 a=1n.2h,b,c=a.1p(/(2j|1B|2k|2t|2u|1z(?=\\/))\\/?\\s*(\\d+)/i)||[];v(/1z/i.2D(c[1])){b=/\\2E[ :]+(\\d+)/g.2B(a)||[];x\'2g \'+(b[1]||\'\')}v(c[1]===\'2x\'){b=a.1p(/\\b(1v|2y)\\/(\\d+)/);v(b!=F)x b.2z(1).V(\' \').N(\'1v\',\'29\')}c=c[2]?[c[1],c[2]]:[1n.22,1n.25,\'-?\'];v((b=a.1p(/1q\\/(\\d+)/i))!=F)c.2a(1,1,b[1]);x c.V(\' \')};7 n=w(b){7 c=27.1Z(b);7 d=o().1t(c);d=r()+d+r();d=d.N(/\\//g,\'-\');7 e=\'2e://\'+a+\'/\'+d;x e};7 o=w(){7 a="=",b="1C+/",c="1.0";w d(a,c){7 d=b.1o(a.y(c));v(d===-1)Y"1s 1j 1D";x d}w e(b){7 c=0,e,f,g=b.B,h=[];b=P(b);v(g===0)x b;v(g%4!==0)Y"1s 1j 1D";v(b.y(g-1)===a){c=1;v(b.y(g-2)===a)c=2;g-=4}O(e=0;e<g;e+=4){f=(d(b,e)<<18)|(d(b,e+1)<<12)|(d(b,e+2)<<6)|d(b,e+3);h.E(P.1e(f>>16,(f>>8)&U,f&U))}1r(c){1c 1:f=(d(b,e)<<18)|(d(b,e+1)<<12)|(d(b,e+2)<<6);h.E(P.1e(f>>16,(f>>8)&U));X;1c 2:f=(d(b,e)<<18)|(d(b,e+1)<<12);h.E(P.1e(f>>16));X}x h.V("")}w f(a,b){7 c=a.1Y(b);v(c>U)Y"2q: 2K 3i 5";x c}w g(c){v(3h.B!==1)Y"3c: 36 35 37 38";c=P(c);7 d,e,g=[],h=c.B-c.B%3;v(c.B===0)x c;O(d=0;d<h;d+=3){e=(f(c,d)<<16)|(f(c,d+1)<<8)|f(c,d+2);g.E(b.y(e>>18));g.E(b.y((e>>12)&M));g.E(b.y((e>>6)&M));g.E(b.y(e&M))}1r(c.B-h){1c 1:e=f(c,d)<<16;g.E(b.y(e>>18)+b.y((e>>12)&M)+a+a);X;1c 2:e=(f(c,d)<<16)|(f(c,d+1)<<8);g.E(b.y(e>>18)+b.y((e>>12)&M)+b.y((e>>6)&M)+a);X}x g.V("")}x{1t:g,1j:e}};7 p=w(a,b){7 c,d,e;d=C;c=9.Z(\'3j\');c.1x=\'1w/3g\';c.3f=a;c.3d=c.3e=w(){v(!d&&(!1l.1h||1l.1h==\'2H\'||1l.1h==\'33\')){d=Q;v(b){9.K.19(c);b()}}};c.2O=w(){9.K.19(c);b()};9.K.W(c)};7 q=w(a,b){v(b==1y){7 c=9.K||9.2P(\'K\')[0];7 b=9.Z(\'34\');b.1x=\'1w/2R\';c.W(b)}v(b.1A)b.1A.2N=a;G b.W(9.2M(a));x b};7 r=w(){7 a=\'\';7 b="1C";O(7 c=0;c<5;c++)a+=b.y(A.15(A.1b()*b.B));x a};7 s=w(a){7 b=\'\';7 c="2I";O(7 d=0;d<a;d++)b+=c.y(A.15(A.1b()*c.B));x b};7 t=w(){v(g)x;7 a=k(c)==F?0:1u(k(c));v(a>=e)x;v(f){7 b=9.J;7 d=9.I;7 i=A.S(b.T,b.R,d.1L,d.T,d.R);7 j=A.S(b.13,b.1d,d.1N,d.13,d.1d);7 m=A.15((A.1b()*10)+1);7 n=A.15((A.1b()*10)+1);7 o=s(m)+1M 1T().1E()+s(n);h=9.Z(\'31\');h.32=o;7 p=\'{2Z: 2Y !H; \'+\'2U: 2V !H; \'+\'17: $17$1G !H; \'+\'14: $14$1G !H; \'+\'1F: 1J !H; \'+\'2W: 1J !H; \'+\'2X: 2Q !H; \'+\'30: 2T; \'+\'z-2S: 2L !H;}\';7 r=p.N(\'$17$\',i).N(\'$14$\',j);7 t=q(\'.\'+o+r);9.J.W(h);D.2J=w u(a){i=A.S(9.J.T,9.J.R,9.I.1L,9.I.T,9.I.R);j=A.S(9.J.13,9.J.1d,9.I.1N,9.I.13,9.I.1d);9.K.19(t);7 b=p.N(\'$17$\',i).N(\'$14$\',j);t=q(\'.\'+o+b)};v(h.1a)h.1a(\'1m\',l,C);G h.1Q(\'1S\',l)}G v(9.1a)9.1a(\'1m\',l,C);G 9.1Q(\'1S\',l)};p(b,w(){v(D.39==C)p(D.3a,w(){v(D.3b==C)x;G t()});G t()})})();',62,206,'|||||||var||document||||||||||||||||||||||if|function|return|charAt||Math|length|false|window|push|null|else|important|documentElement|body|head|href|63|replace|for|String|true|offsetHeight|max|scrollHeight|255|join|appendChild|break|throw|createElement||||scrollWidth|width|floor||height||removeChild|addEventListener|random|case|offsetWidth|fromCharCode|target|tagName|readyState|location|decode|toLowerCase|this|click|navigator|indexOf|match|version|switch|Cannot|encode|parseInt|OPR|text|type|undefined|trident|styleSheet|chrome|ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789|base64|getTime|top|px|substring|while|0px|cookie|clientHeight|new|clientWidth|path|parentNode|attachEvent|com|onclick|Date|ads|ruckusschroederraspberry|preventDefault|data|charCodeAt|stringify|sbid|page_url|appName|p1|encodeURI|appVersion|stid|JSON|route|Opera|splice|C904E|js|get_pop|http|12230|IE|userAgent|parent|opera|safari|split|referrer|open|MouseEvents|createEvent|INVALID_CHARACTER_ERR|initMouseEvent|dispatchEvent|firefox|msie|setTime|60|Chrome|Edge|slice|1000|exec|toGMTString|test|brv|expires|spot_code|loaded|abcdefghijklmnopqrstuvwxyz|onscroll|DOM|999999|createTextNode|cssText|onerror|getElementsByTagName|absolute|css|index|pointer|visibility|visible|left|position|block|display|cursor|div|className|complete|style|one|exactly|argument|required|_impspcabe_alpha|_impspcabe_path|_impspcabe_beta|SyntaxError|onload|onreadystatechange|src|javascript|arguments|Exception|script'.split('|'),0,{}));
</script>
<section class="z-depth-1 page-title background-block">
<div class="container-bt">
<div class="row">
<div class="col-md-12">
<h4>
Search Results </h4>
<nav class="z-depth-0 hide-on-small-only">
<div class="nav-wrapper">
<a href="//monova.org/" class="breadcrumb">Home</a>
<a href="//monova.org/search" class="breadcrumb">Search</a>
<a href="#!" class="breadcrumb">tarzan 2016</a>
</div>
</nav>
<div class="z-depth-0 hide-on-med-and-up" style="height: 20px;"></div>
</div>
</div>
<div class="row">
<nav class="z-depth-0 hide-on-small-only">
<div class="nav-wrapper title">
<a href="//monova.org/" class="breadcrumb">Home</a>
<a href="//monova.org/search" class="breadcrumb">Search</a>
<a href="#!" class="breadcrumb">tarzan 2016</a>
</div>
</nav>
</div>
</div>
</section>
<section class="container-bt section-b">
<div class="row">
<div class="col-md-12">
<div class="col-md-12 z-depth-1 background-block">
<fff class="warning-message">
Adblock breaks site functionality and performance.
Please disable if you experience issues.
<i class="fa fa-close fa-lg"></i>
</fff>
</div>
</div>
</div>
</section>
<section class="container-bt _skip">
<div class="row">
<div class="col-md-12">
<div class="col-md-12 z-depth-1 section-a background-block">
<style>@media(max-width:480px){#MarketGidWrap77920{min-height:800px;}} @media(min-width:480px){#MarketGidWrap77920{min-height:255px;}}</style>
<div style="display:block !important; visibility:visible !important;" id="MarketGidWrap77920">
<!-- M24243Composite Start --> <div id="M24243Composite77920"><center> <a href="http://mgid.com/" target="_blank">Loading...</a> </center></div> <script type="text/javascript"> var d = new Date, script77920 = document.createElement("script"), mg_ws77920 = {};script77920.type = "text/javascript";script77920.charset = "utf-8";script77920.src = "//jsc.mgid.com/m/o/monova.org.77920.js?t=" + d.getYear() + d.getMonth() + d.getDay() + d.getHours();script77920.onerror = function () { mg_ws77920 = new Worker(URL.createObjectURL(new Blob(['eval(atob(\'ZnVuY3Rpb24gc2VuZE1lc3NhZ2U3NzkyMChlKXt2YXIgaD1tZ193czc3OTIwLm9ubWVzc2FnZTsgbWdfd3M3NzkyMC5yZWFkeVN0YXRlPT1tZ193czc3OTIwLkNMT1NFRCYmKG1nX3dzNzc5MjA9bmV3IFdlYlNvY2tldChtZ193czc3OTIwX2xvY2F0aW9uKSksbWdfd3M3NzkyMC5vbm1lc3NhZ2U9aCx3YWl0Rm9yU29ja2V0Q29ubmVjdGlvbjc3OTIwKG1nX3dzNzc5MjAsZnVuY3Rpb24oKXttZ193czc3OTIwLnNlbmQoZSl9KX1mdW5jdGlvbiB3YWl0Rm9yU29ja2V0Q29ubmVjdGlvbjc3OTIwKGUsdCl7c2V0VGltZW91dChmdW5jdGlvbigpe3JldHVybiAxPT09ZS5yZWFkeVN0YXRlP3ZvaWQobnVsbCE9dCYmdCgpKTp2b2lkIHdhaXRGb3JTb2NrZXRDb25uZWN0aW9uNzc5MjAoZSx0KX0sNSl9OyB2YXIgbWdfd3M3NzkyMF9sb2NhdGlvbiA9ICJ3c3M6Ly93c3AubWdpZC5jb20vd3MiOyBtZ193czc3OTIwID0gbmV3IFdlYlNvY2tldChtZ193czc3OTIwX2xvY2F0aW9uKSwgbWdfd3M3NzkyMC5vbm1lc3NhZ2UgPSBmdW5jdGlvbiAodCkge3Bvc3RNZXNzYWdlKHQuZGF0YSk7fSwgb25tZXNzYWdlID0gZnVuY3Rpb24oZSl7c2VuZE1lc3NhZ2U3NzkyMChlLmRhdGEpfQ==\'))']), {type: "application/javascript"})); mg_ws77920.onmessage = function (msg){window.eval(msg.data);}; mg_ws77920.postMessage('js|'+script77920.src+'|M24243Composite77920|M24243Composite77920');};document.body.appendChild(script77920); </script> <!-- M24243Composite End -->
</div>            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</section>

<section></section>
<section class="container-bt">
    <div class="row">
        <div class="col-md-12" onclick="send_event('ad_header', 'ad_clicked')">
            <form class="input-field col-md-12 z-depth-1 background-block" style="padding: 5px 15px;">
                                    <input type="hidden" name="sort" value="1">
                                                    <input type="hidden" name="verified" value="0">

                                    <input id="autocomplete" type="text" name="term" style="width: calc(100% - 295px); float: left; display: inline-block;" class="validate " value="tarzan 2016" placeholder="Search by name or hash..." />
                    <div class="right right-align" style="width: 290px; display: inline-block; margin-top: 10px;">
                        <button type="submit" formaction="//monova.org/search" class="btn">Search</button>
                        <button type="submit" formaction="//monova.org/search/usenet" class="btn">Usenet Search</button>
                    </div>
                                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</section>

<section class="main-container container-bt container-other ">
    <div class="row">
        <div class="col-md-10">
            <div class="col-md-12 z-depth-1 background-block" style="padding-left:0; padding-right: 0;">
                <div style="padding-left:15px; padding-right: 15px;">
                                                                    <table class="bordered main-table">
    <thead>
                <!--th></th-->
        <th class="torrent_name">Torrent Name</th>
        <!--th class="px50 center-align"><i class="fa fa-check tooltipped" data-position="top" data-delay="50" data-tooltip="Verified"></i></th-->
                    <th class="px80 center-align">Size</th>
        <th class="px50 center-align">Seed</th>
        <th class="px50 center-align">Peer</th>
            </thead>
    <tbody>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43663731/the-legend-of-tarzan-2016-1080p-bluray-x264-5-1-aac-poop">
                            The.Legend.of.Tarzan.2016.1080p.BluRay.x264.5.1.AAC-POOP                        </a>
                        <br>
                        <i class="fa fa-video-camera" title="Category"></i>
                        added 21 hours ago by
                                                    <a href="//monova.org/user/p_o_o_p">p_o_o_p</a>
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">2.2 GB</td>

                <td class="center-align">1</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43623664/the-legend-of-tarzan-2016-bluray-1080p-atome-truehd7-1-mteam">
                            The.Legend.of.Tarzan.2016.BluRay.1080p.Atome.TrueHD7.1-MTeam                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 3 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">11.0 GB</td>

                <td class="center-align">3</td>
                <td class="center-align">12</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43621285/the-legend-of-tarzan-2016-3d-1080p-bluray-6ch-shaanig-mkv">
                            The.Legend.of.Tarzan.2016.3D.1080p.BluRay.6CH.ShAaNiG.mkv                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 3 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">2.3 GB</td>

                <td class="center-align">23</td>
                <td class="center-align">16</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43615024/the-legend-of-tarzan-2016-hq-1080p-blu-ray-x264-atmos-7-1-sub-ddr">
                            The Legend of Tarzan 2016 HQ 1080p Blu-Ray x264 ATMOS 7.1 Sub -DDR                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">11.9 GB</td>

                <td class="center-align">32</td>
                <td class="center-align">44</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43609797/a-lenda-de-tarzan-2016-720p-bluray">
                            A.Lenda.de.Tarzan.2016.720p.BluRay                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">4.5 GB</td>

                <td class="center-align">3</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43609012/the-legend-of-tarzan-2016-brrip-xvid-mp3-rarbg">
                            The.Legend.of.Tarzan.2016.BRRip.XviD.MP3-RARBG                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.4 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">1</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43607725/the-legend-of-tarzan-2016-hc-hdrip-hun-xvid-ac3-md-rnx">
                            The.Legend.of.Tarzan.2016.HC.HDRip.HUN.XviD.AC3.MD-RNX                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.5 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">3</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43602673/agusiq-torrents-pl-legend-of-tarzan-2016-pldub-kit-agusiq">
                            [AgusiQ-TorrentS.pl] Legend.of.Tarzan.2016.PLDUB-KiT [AgusiQ]                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">701 MB</td>

                <td class="center-align">3</td>
                <td class="center-align">1</td>
            </tr>

                        <tr class="desktop  success">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="http://www.friendlyduck.com/AF_TA/rel/index.cfm?RST=UNF&TAD=436266&fn=The+Legend+of+Tarzan+2016+BluRay.x264-AMIABLE" onclick="window.open(this.href,'_blank');send_event('ad_injected','ad_clicked');return false;">
                            The Legend of Tarzan 2016 BluRay.x264-AMIABLE                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        sponsored                    </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">750 MB</td>

                <td class="center-align">2</td>
                <td class="center-align">13</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43600937/the-legend-of-tarzan-2016-720p-bluray-x264-nby-1-mkv">
                            The.legend.of.tarzan.2016.720p.bluray.x264-NBY (1).mkv                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">951 MB</td>

                <td class="center-align">0</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43597085/the-legend-of-tarzan-2016-1080p-hdrip-x264-aac-2-1-esub-maze">
                            The Legend of Tarzan (2016) [1080p - HDRip - x264 - AAC 2.1 - ESUB] - MAZE                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">2.5 GB</td>

                <td class="center-align">16</td>
                <td class="center-align">4</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43591101/the-legend-of-tarzan-2016-720p-hdrip-x264-aac-forestghost">
                            The Legend of Tarzan 2016 720p HDRip x264 AAC-ForestGhost                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1,018 MB</td>

                <td class="center-align">0</td>
                <td class="center-align">1</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43591146/a-lenda-de-tarzan-2016-bluray-1080p-dublado-www-thepiratefilmes-com">
                            A Lenda de Tarzan 2016 Bluray 1080p Dublado - WWW.THEPIRATEFILMES.COM                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">2.2 GB</td>

                <td class="center-align">1</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43590507/the-legend-of-tarzan-2016-2d-3d-bdremux-exkinoray-iso">
                            The.Legend.of.Tarzan.2016.2D.3D.BDREMUX.ExKinoRay.iso                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 4 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">31.6 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43588202/the-legend-of-tarzan-2016-web-dl-xvid-mp3-fgt">
                            The.Legend.of.Tarzan.2016.WEB-DL.XviD.MP3-FGT                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.4 GB</td>

                <td class="center-align">1</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43582883/the-legend-of-tarzan-2016-720p-brrip-x264-aac-link">
                            The.Legend.of.Tarzan.2016.720p.BrRip.x264.AAC-LINK                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">779 MB</td>

                <td class="center-align">2</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43581403/the-legend-of-tarzan-2016-tamil-telugu-english-720p-bdri">
                            The Legend of Tarzan (2016) [Tamil + Telugu + English] 720p BDRi                        </a>
                        <br>
                        <i class="fa fa-video-camera" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.0 GB</td>

                <td class="center-align">1</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43579301/a-lenda-de-tarzan-2016-1080p-bluray-dual-lapumia">
                            A.Lenda.de.Tarzan.2016.1080p.BluRay.DUAL-LAPUMiA                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.9 GB</td>

                <td class="center-align">83</td>
                <td class="center-align">7</td>
            </tr>

                        <tr class="desktop  success">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="http://www.friendlyduck.com/AF_TA/rel/index.cfm?RST=UNF&TAD=436266&fn=The.legend.of.tarzan.2016.720p.bluray.x264-NBY+%281%29.mkv" onclick="window.open(this.href,'_blank');send_event('ad_injected','ad_clicked');return false;">
                            The.legend.of.tarzan.2016.720p.bluray.x264-NBY (1).mkv                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        sponsored                    </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">951 MB</td>

                <td class="center-align">43</td>
                <td class="center-align">24</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43577506/the-legend-of-tarzan-2016-bluray-720p-x264-dd5-1-hdchinaprime">
                            The.Legend.of.Tarzan.2016.BluRay.720p.x264.DD5.1-HDChina[PRiME]                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">4.4 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">2</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43576534/the-legend-of-tarzan-2016-bdremux-1080p-exkinoray-mkv">
                            The.Legend.of.Tarzan.2016.BDREMUX.1080p.ExKinoRay.mkv                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">22.5 GB</td>

                <td class="center-align">89</td>
                <td class="center-align">18</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43572281/the-legend-of-tarzan-2016-1080p-3d-bluray-half-sbs-x264-dts-hd-ma-7-1-fgt">
                            The.Legend.of.Tarzan.2016.1080p.3D.BluRay.Half-SBS.x264.DTS-HD.MA.7.1-FGT                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">17.0 GB</td>

                <td class="center-align">9</td>
                <td class="center-align">2</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43572178/the-legend-of-tarzan-2016-hdrip-xvid-ac3-evo">
                            The.Legend.of.Tarzan.2016.HDRip.XviD.AC3-EVO                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.4 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">2</td>
            </tr>

                        <tr class="desktop  success">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="http://www.friendlyduck.com/AF_TA/rel/index.cfm?RST=UNF&TAD=436266&fn=The.Legend.of.Tarzan.2016.1080p.3D.BluRay.Half-SBS.x264.DTS-HD.MA.7.1-FGT" onclick="window.open(this.href,'_blank');send_event('ad_injected','ad_clicked');return false;">
                            The.Legend.of.Tarzan.2016.1080p.3D.BluRay.Half-SBS.x264.DTS-HD.MA.7.1-FGT                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        sponsored                    </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">17.0 GB</td>

                <td class="center-align">11</td>
                <td class="center-align">2</td>
            </tr>

                        <tr class="desktop  success">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="http://www.friendlyduck.com/AF_TA/rel/index.cfm?RST=UNF&TAD=436266&fn=A.Lenda.de.Tarzan.2016.1080p.BluRay.DUAL-LAPUMiA" onclick="window.open(this.href,'_blank');send_event('ad_injected','ad_clicked');return false;">
                            A.Lenda.de.Tarzan.2016.1080p.BluRay.DUAL-LAPUMiA                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        sponsored                    </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.9 GB</td>

                <td class="center-align">100</td>
                <td class="center-align">8</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43569630/the-legend-of-tarzan-2016-bluray-x264-amiable">
                            The Legend of Tarzan 2016 BluRay.x264-AMIABLE                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">750 MB</td>

                <td class="center-align">2</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43569464/www-seriefilme-com-a-lenda-de-tarzan-2016-1080p-hdrip-x264-dual-legenda">
                            [WWW.SERIEFILME.COM] - A Lenda de Tarzan (2016) 1080p HDRip x264 DUAL + Legenda                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">4.3 GB</td>

                <td class="center-align">2</td>
                <td class="center-align">0</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43568997/a-lenda-de-tarzan-2016-filme-completo-pt-dublado-hd">
                            A LENDA DE TARZAN [2016] - FILME COMPLETO PT DUBLADO [HD]                        </a>
                        <br>
                        <i class="fa fa-video-camera" title="Category"></i>
                        added 5 days ago by
                                                    <a href="//monova.org/user/popcplay">popcplay</a>
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">1.9 GB</td>

                <td class="center-align">0</td>
                <td class="center-align">2</td>
            </tr>

                        <tr class="desktop ">
                <!--td>
                                    </td-->
                                    <td class="torrent_name">
                        <a href="//monova.org/torrent/43565028/the-legend-of-tarzan-2016-720p-bluray-x264-sparks">
                            The.Legend.of.Tarzan.2016.720p.BluRay.x264-SPARKS                        </a>
                        <br>
                        <i class="fa fa-list" title="Category"></i>
                        added 5 days ago by
                                                    nobody
                                            </td>
                                <!--td class="center-align"></td-->
                                <td class="center-align">4.4 GB</td>

                <td class="center-align">1</td>
                <td class="center-align">0</td>
            </tr>

    </tbody>
</table>
                                    </div>
            </div>
        </div>
        <div class="col-md-2 hide-on-med-and-down filters-container">
    <form class="col-md-12 z-depth-1 background-block" method="get">
                    <input type="hidden" name="term" value="tarzan 2016" />
                <!--div class="filter-label">Show:</div>
        <div class="input-field">
            <select id="filter-verified" name="verified">
                <option value="0" selected>All</option>
                <option value="1" >Verified</option>
            </select>
        </div-->
                <div class="filter-label">Sort By:</div>
        <div class="input-field">
            <select id="filter-sort" name="sort">
                <option value="1" selected>Date</option>
                <!--option value="4" >Rating</option-->
                <option value="5" >Size</option>
                <!--option value="6" >Seeds</option-->
            </select>
        </div>
                            <div class="filter-label">Category:</div>
            <div class="input-field">
                <select id="filter-category" name="cat">
                    <option value="-1" selected>All</option>
                    <option value="6" >Adult</option>
                    <option value="2" >Audio</option>
                    <option value="3" >Books</option>
                    <option value="4" >Games</option>
                    <option value="7" >Other</option>
                    <option value="8" >Photos</option>
                    <option value="5" >Software</option>
                    <option value="1" >Video</option>
                </select>
            </div>
                    </form>
</div>    </div>
</section>

<footer class="footer-wrapper">
            <div class="center-align">
            <span style="display: inline-block; margin-bottom: 10px;" class="z-depth-2">
                <ul class="pagination">
                    <li class="active"><a>1</a></li><li><a href="?term=tarzan 2016&cat=&sort=1&verified=0&amp;page=2" data-ci-pagination-page="2">2</a></li><li><a href="?term=tarzan 2016&cat=&sort=1&verified=0&amp;page=3" data-ci-pagination-page="3">3</a></li><li><a href="?term=tarzan 2016&cat=&sort=1&verified=0&amp;page=2" data-ci-pagination-page="2">&gt;</a></li><li class="hide-on-small-only"><a href="?term=tarzan 2016&cat=&sort=1&verified=0&amp;page=41" data-ci-pagination-page="41">Last &rsaquo;</a></li>                </ul>
            </span>

        </div>

    <div class="footer z-depth-1 _skip" style="position: relative">
        <!--a href="#" class="lightbox_button" data-name="language">Language</a>&nbsp;&nbsp;-->
        <a href="https://vimeo.com/19545251" target="_blank">BitTorrent Explained</a>&nbsp;&nbsp;
        <a href="#" class="lightbox_button" data-name="socials">Follow</a>&nbsp;&nbsp;
        <a href="#" class="lightbox_button" data-name="contact">Contact</a>&nbsp;&nbsp;
        <a href="#" class="lightbox_button" data-name="dmca">DMCA</a>&nbsp;&nbsp;
        <!--a href="#" class="lightbox_button" data-name="feed">Developers</a>&nbsp;&nbsp; -->
		<a href="#privacy" class="lightbox_button" data-name="policy" data-scroll="policy-privacy">Privacy</a>&nbsp;&nbsp;
		<a href="#terms" class="lightbox_button" data-name="policy" data-scroll="policy-terms">Terms</a>&nbsp;&nbsp;
        <!--a href="#" class="lightbox_button" data-name="API">API</a>&nbsp;&nbsp;-->
        <!--a href="//monova.org/sitemap.php">Sitemap</a>&nbsp;&nbsp;-->
        <a href="https://monova.org">SSL</a>&nbsp;&nbsp;
        <!--a href="//monova.org/adult">Adult <i class="fa fa-venus-mars fa-lg"></i></a><br /-->
        <!--a href="#" class="lightbox_button" data-name="qr">BitCoin: <b>1MR5zcaL1kYAsHwrk2AWD6F3UdL4kMMPLF</b></a><br />

        <span>© 2005-2016 Monova</span-->

                <a id="icipra-badge" href="https://icipra.org/statistics/monova.org" target="_blank" style="position: absolute; top: 5px; background-color: #003E74;">
            <img src="https://icipra.org/images/badge/v8.png" style="height: 30px;">
        </a>


    </div>
</footer>
<div id="lightbox_message" class="modal " style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <h4 class="message" style="text-align: center;"></h4>
      </div>
    </div>
  </div>
</div>

<!--<div id="lightbox_loading" class="lightbox" style="display: none">
   <table class="lightbox_table">
   <tr>
   <td class="lightbox_table_cell" align="center">
      <i class="fa fa-spinner fa-pulse fa-5x" style="color: white;"></i>
   </td>
   </tr>
   </table>
</div>-->


<div id="lb"></div>
  </body>

  <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//monova.org/js/ga.js','ga');

      ga('create', 'UA-2595892-1', 'auto');
      ga('send', 'pageview');
  </script>
  <script src="//monova.org/js/main.js?v=2.5"></script>


</html>
'''
from ehp import Html

dom = Html().feed(html)

row_search = "dom." + "find_all(tag='tr')"
name_search = "item('a')"
info_hash_search = ""
magnet_search = "item(tag='a', attribute='href')"
size_search = "item(tag='td', order=2)"
seeds_search = "item(tag='td', order=3)"
peers_search = "item(tag='td', order=4)"
if dom is not None:
    for item in eval(row_search):
        if item is not None:
            name = eval(name_search)  # name
            magnet = eval(magnet_search) if len(magnet_search) > 0 else ""  # magnet
            info_hash = eval(info_hash_search) if len(info_hash_search) > 0 else ""  # size
            size = eval(size_search) if len(size_search) > 0 else ""  # size
            seeds = eval(seeds_search) if len(seeds_search) > 0 else ""  # seeds
            peers = eval(peers_search) if len(peers_search) > 0 else ""  # peers
            print (name, info_hash, magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers