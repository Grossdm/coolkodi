import utils
text = 1.2
print isinstance(text, (long, int))
print utils.size_int("1,000.2")
print utils.size_int("1.2GB")

