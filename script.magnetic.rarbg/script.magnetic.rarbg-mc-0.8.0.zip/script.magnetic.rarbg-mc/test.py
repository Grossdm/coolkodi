# coding: utf-8
__author__ = 'mancuniancol'

html = '''

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="auto">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Come and download spectre absolutely for free. Fast downloads."/>
    <meta name="robots" content="noindex" rel="usearch"/>
    <title>Download spectre Torrents  - Kickass Torrents</title>
    <link rel="stylesheet" type="text/css" href="//kastatic.com/all-e3ac838.css" charset="utf-8" />
    <link rel="shortcut icon" href="//kastatic.com/images/favicon.ico" />


    <link rel="apple-touch-icon" href="//kastatic.com/images/apple-touch-icon.png" />

    <!--[if IE 7]>
    <link href="//kastatic.com/css/ie7-e3ac838.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if IE 8]>
    <link href="//kastatic.com/css/ie8.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if lt IE 9]>
    <script src="//kastatic.com/js/html5.min-e3ac838.js" type="text/javascript"></script>
    <![endif]-->

    <!--[if gte IE 9]>
    <link href="//kastatic.com/css/ie9-e3ac838.css" rel="stylesheet" type="text/css"/>
    <![endif]-->
    <script type="text/javascript">
        +function(S,p,a,r,e,C,l,i,c,k)
        { S[r]=S[r]||[];S[e]||(S[e]=function(){
        S[r].push(Array.prototype.slice.call(arguments)) });
        i=p.createElement(a);c=p.getElementsByTagName(a)[0];
        i.src=C;i.async=true;c.parentNode.insertBefore(i,c)}
        (window,document,'script','_scq','sc', '//a.kickass.to/sc-e3ac838.js');

        sc('setHost', 'a.kickass.to');
        sc('setAccount', '_b894d6cb1e370fb9ad89f8d6d99eeb33');
            var kat = {
            release_id: 'e3ac838',
            detect_lang: 0,
            spare_click: 1,
            mobile: false
        };
    </script>
    <script src="//kastatic.com/js/all-e3ac838.js" type="text/javascript"></script>
    <link rel="alternate" type="application/rss+xml" title="Subscribe to RSS feed" href="http://kat.cr/usearch/spectre/?rss=1"/>
        <meta name="verify-v1" content="YccN/iP28SifHNEFY6u92i0ou3tAegQAIk2OyOJLp1s="/>
    <meta name="y_key" content="f0b40c3f5fee758f"/>
    <meta name="google-site-verification" content="C1rNEC4fJIvFoyyccMV2PbuqX3P-SFtlD2MNZ9D2uy0" />
    <link rel="search" type="application/opensearchdescription+xml" title="KickassTorrents Torrent Search" href="/opensearch.xml"/>
    <meta property="fb:app_id" content="123694587642603"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
</head>
<body class="mainBody">
<div id="wrapper">
    <div id="wrapperInner">
<div  data-sc-slot="_60318cd4e8d28f6fb76fe34e9bd9c498"></div>
<div  data-sc-slot="_39ecb76dd457e5ac33776fdf11500d56"></div>
    <div id="logindiv"></div>
    <header>
	<nav id="menu">
		<a href="/" id="logo"></a>
		<a href="#" id="showHideSearch"><i class="ka ka-zoom"></i></a>
		<div id="torrentSearch">
			<form action="/usearch/" method="get" id="searchform" accept-charset="utf-8" onsubmit="return doSearch(this.q.value);">
				<input id="contentSearch" class="input-big" type="text" name="q" value="spectre" autocomplete="off" placeholder="Search query" /><div id="searchTool"><a title="Advanced search" href="/advanced/?q=spectre" class="ajaxLink"><i class="ka ka-settings"></i></a><button title="search" type="submit" value="" onfocus="this.blur();" onclick="this.blur();"><i class="ka ka-search"></i></button></div>
			</form>
		</div>
        <div  data-sc-slot="_277923e5f9d753c5b0630c28e641790c"></div>
		<ul id="navigation">

			<li> <a href="/browse/"> <i class="ka ka-torrent"></i><span class="menuItem">browse</span></a>
				<ul class="dropdown dp-middle dropdown-msg upper">

						<li class="topMsg"><a href="/new/"><i class="ka ka16 ka-torrent"></i>latest</a></li>
										<li class="topMsg"><a href="/movies/"><i class="ka ka16 ka-movie lower"></i>Movies</a></li>
					<li class="topMsg"><a href="/tv/"><i class="ka ka16 ka-movie lower"></i>TV</a></li>
					<li class="topMsg"><a href="/music/"><i class="ka ka16 ka-music-note lower"></i>Music</a></li>
					<li class="topMsg"><a href="/games/"><i class="ka ka16 ka-settings lower"></i>Games</a></li>
					<li class="topMsg"><a href="/books/"><i class="ka ka16 ka-bookmark"></i>Books</a></li>
					<li class="topMsg"><a href="/applications/"><i class="ka ka16 ka-settings lower"></i>Apps</a></li>
					<li class="topMsg"><a href="/anime/"><i class="ka ka16 ka-movie lower"></i>Anime</a></li>
					<li class="topMsg"><a href="/other/"><i class="ka ka16 ka-torrent"></i>Other</a></li>
											<li class="topMsg"><a href="/xxx/"><i class="ka ka16 ka-delete"></i>XXX</a></li>
									</ul>
			</li>
			</li>
			<li><a data-nop href="/community/"> <i class="ka ka-community"></i><span class="menuItem">Community</span></a>
			<li><a data-nop href="/blog/"><i class="ka ka-rss lower"></i><span class="menuItem">Blog</span></a></li>
			<li><a data-nop href="/faq/"><i class="ka ka-faq lower"></i><span class="menuItem">FAQ</span></a></li>
			</li>

			<li> <a data-nop href="/auth/login/" class="ajaxLink"><i class="ka ka-user"></i><span class="menuItem">Register / Sign In</span></a></li>
		</ul>
	</nav>
</header>

<div class="pusher"></div>
<div class="mainpart">


<table width="100%" cellspacing="0" cellpadding="0" class="doublecelltable" id="mainSearchTable">
	<tr>
		<td width="100%">
							<div class="spareBlock hzSpare">
    <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
    <div  data-sc-slot="_b77c3599a877a4e9d6097b83ec9f23bb" data-sc-params="{ 'searchQuery': 'spectre' }"></div>
</div>

										<div class="tabs">
	<ul class="tabNavigation">
		<li><a class="selectedTab" href="/search/spectre/"><span>Sponsored Links</span></a></li>
	</ul>
	<hr class="tabsSeparator"/>
</div>
<div  data-sc-slot="_c039297fb3d18cf107e21460970475f0"></div>
<br /><br />

						            								        		    <h1><a itemprop="url" class="plain" href="/spectre-i2379713/">Spectre</a></h1>
				<div class="torrentMediaInfo">
    <a class="movieCover" href="/spectre-i2379713/"><img src="//yuq.me/movies/23/797/2379713.jpg" /></a>
    <div class="dataList">
        <ul class="block overauto botmarg0">
            <li><strong>IMDb link:</strong> <a class="plain" href="http://www.imdb.com/title/tt2379713/">2379713</a></li>
                        <li><strong>IMDb rating:</strong> 6.9 (247,144 votes) </li>
                                    <li><strong>RottenTomatoes:</strong> <span class="rottentomatoes positive" title="rotten!"></span>64% <span class="rottenaudience positive" title="spilled"></span>62% </li>
                                        <li><strong>Watch on <a data-nop target="_blank" href="https://www.solarmovie.ph">Solarmovie</a>:</strong> <a data-nop target="_blank" href="https://www.solarmovie.ph/watch-spectre-2015.html">Spectre</a></li>
                                    <li><strong>Genres:</strong>  <a class="plain" href="/movies/genre/action/"><span>Action</span></a>,  <a class="plain" href="/movies/genre/adventure/"><span>Adventure</span></a>,  <a class="plain" href="/movies/genre/thriller/"><span>Thriller</span></a>,  <a class="plain" href="/movies/genre/crime/"><span>Crime</span></a> </li>
                    </ul>
        <ul>
                    <li><a href="/bookmarks/add/movie/2379713/" class="ajaxLink kaButton smallButton normalText"><i class="ka ka-bookmark"></i> add <strong>Spectre</strong> to bookmarks</a></li>
                                <li><strong>Release date:</strong> 06 November 2015</li>
                                <li><strong>Writers:</strong> John Logan (screenplay), Neal Purvis (screenplay), Robert Wade (screenplay), Jez Butterworth (screenplay), John Logan (story), Neal Purvis (story), Robert Wade (story), Ian Fleming (characters)</li>

                    <li><strong>Director:</strong> <span><a href="/movies/director/sam-mendes-a0005222/">Sam Mendes</a></li>
                                                </ul>
                <div class="floatleft width100perc botmarg10px"><strong>Cast:</strong>  <span><a href="/movies/actor/ralph-fiennes-a0000146/">Ralph Fiennes</a></span>,              <span><a href="/movies/actor/daniel-craig-a0185819/">Daniel Craig</a></span>,              <span><a href="/movies/actor/christoph-waltz-a0910607/">Christoph Waltz</a></span>,              <span><a href="/movies/actor/dave-batista-a1176985/">Dave Batista</a></span> and others             </div>
                        <div class="floatleft width100perc botmarg10px">
            <strong>Summary:</strong>
                <div id="summary">
<p class="accentbox botmarg10px">
    A cryptic message from Bond's past sends him on a trail to uncover a sinister organization. While M battles political forces to keep the secret service alive, Bond peels back the layers of deceit to reveal the terrible truth behind SPECTRE.<br />
    </p>
<strong><small>Written by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/VoodooKid/">VoodooKid</a></span><span title="Reputation" class="repValue positive">1984</span></span></small></strong>




    </div>

        </div>
        <div  data-sc-slot="_16b9d77edbc49edc5a7a757cde4dfe28" data-sc-params="{ 'movie_name': 'Spectre' }"></div>
<div  data-sc-slot="_09f629b563a9bad8e0f409ee6e37b804"></div>
                <div class="pages marg0 floatleft"> <strong class="botpad5px block">Available in versions:</strong> <a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#1080p">1080p</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#720p">720p</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#Blu-Ray">Blu-Ray</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#BDRip">BDRip</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#HDRiP">HDRiP</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#DVD">DVD</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#DVDRip">DVDRip</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#x264">x264</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#x265">x265</a><a class="turnoverButton siteButton bigButton " href="/spectre-i2379713/#Screener">Screener</a> </div>
            </div>
    <!-- div class="dataList" -->
</div>



	        <div class="tabs">
	<ul class="tabNavigation">
        <li>
            <a class="darkButton selectedTab" href="/usearch/spectre/"><span>All</span></a>
        </li>
        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:movies/"><span>Movies <i class="menuValue">299</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:tv/"><span>TV <i class="menuValue">22</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:anime/"><span>Anime <i class="menuValue">1</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:music/"><span>Music <i class="menuValue">43</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:books/"><span>Books <i class="menuValue">33</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:games/"><span>Games <i class="menuValue">9</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:applications/"><span>Apps <i class="menuValue">1</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/spectre category:xxx/"><span>XXX <i class="menuValue">6</i></span></a>
        </li>
	</ul>
	<hr class="tabsSeparator"/>
</div>

			<div><h2>									spectre							<span>  results 1-25 from 425</span>  <a data-nop class="ka ka16 ka-rss normalText rsssign ka-red" target="_blank" href="http://kat.cr/usearch/spectre/?rss=1" title="rss"></a></h2>


	<table cellpadding="0" cellspacing="0" class="data" style="width: 100%">
		<tr class="firstr">
			<th class="width100perc nopad">torrent name</th>
        						<th class="center"><a href="/usearch/spectre/?field=size&sorder=desc" rel="nofollow">size</a></th>
						<th class="center"><span class="files"><a href="/usearch/spectre/?field=files_count&sorder=desc" rel="nofollow">files</a></span></th>
						<th class="center"><span><a href="/usearch/spectre/?field=time_add&sorder=desc" rel="nofollow">age</a></span></th>
						<th class="center"><span class="seed"><a href="/usearch/spectre/?field=seeders&sorder=desc" rel="nofollow">seed</a></span></th>
						<th class="lasttd nobr center"><a href="/usearch/spectre/?field=leechers&sorder=desc" rel="nofollow">leech</a></th>
</tr>
						<tr class="odd" id="torrent_spectre11918813">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11918813,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-1080p-bluray-x264-dts-jyk-t11918813.html#comment">860 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-1080p-bluray-x264-dts-jyk-t11918813.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%201080p%20BluRay%20x264%20DTS-JYK', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:5685BEC720F34C15F538F0304E168DB29292A418&dn=spectre+2015+1080p+bluray+x264+dts+jyk&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:5685BEC720F34C15F538F0304E168DB29292A418&dn=spectre+2015+1080p+bluray+x264+dts+jyk&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/5685BEC720F34C15F538F0304E168DB29292A418.torrent?title=[kat.cr]spectre.2015.1080p.bluray.x264.dts.jyk" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-1080p-bluray-x264-dts-jyk-t11918813.html" class="torType filmType"></a>
                <a href="/spectre-2015-1080p-bluray-x264-dts-jyk-t11918813.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-1080p-bluray-x264-dts-jyk-t11918813.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 1080p BluRay x264 DTS-JYK</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/condors/">condors</a> in <span id="cat_11918813"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.73 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="17 Jan 2016, 08:10">3&nbsp;months</td>
			<td class="green center">3593</td>
			<td class="red lasttd center">454</td>
			</tr>
						<tr class="even" id="torrent_spectre11918911">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11918911,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-720p-brrip-x264-aac-etrg-t11918911.html#comment">381 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-720p-brrip-x264-aac-etrg-t11918911.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20720p%20BRRip%20x264%20AAC-ETRG', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:3EAE3402270F76E881D9FF7BC04BD6D1CE9ADDA8&dn=spectre+2015+720p+brrip+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:3EAE3402270F76E881D9FF7BC04BD6D1CE9ADDA8&dn=spectre+2015+720p+brrip+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/3EAE3402270F76E881D9FF7BC04BD6D1CE9ADDA8.torrent?title=[kat.cr]spectre.2015.720p.brrip.x264.aac.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-720p-brrip-x264-aac-etrg-t11918911.html" class="torType filmType"></a>
                <a href="/spectre-2015-720p-brrip-x264-aac-etrg-t11918911.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-720p-brrip-x264-aac-etrg-t11918911.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 720p BRRip x264 AAC-ETRG</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/megaradon/">megaradon</a> in <span id="cat_11918911"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.09 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="17 Jan 2016, 08:38">3&nbsp;months</td>
			<td class="green center">2999</td>
			<td class="red lasttd center">265</td>
			</tr>
						<tr class="odd" id="torrent_spectre11921345">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11921345,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-french-bdrip-xvid-glups-t11921345.html#comment">29 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-french-bdrip-xvid-glups-t11921345.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20FRENCH%20BDRip%20XviD-GLUPS', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:910AD53C13C7BD4840C135519CCC4A0471E93503&dn=spectre+2015+french+bdrip+xvid+glups&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:910AD53C13C7BD4840C135519CCC4A0471E93503&dn=spectre+2015+french+bdrip+xvid+glups&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/910AD53C13C7BD4840C135519CCC4A0471E93503.torrent?title=[kat.cr]spectre.2015.french.bdrip.xvid.glups" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-french-bdrip-xvid-glups-t11921345.html" class="torType filmType"></a>
                <a href="/spectre-2015-french-bdrip-xvid-glups-t11921345.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-french-bdrip-xvid-glups-t11921345.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 FRENCH BDRip XviD-GLUPS</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/filoumouton/">filoumouton</a> in <span id="cat_11921345"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.37 <span>GB</span></td>
			<td class="center">2</td>
			<td class="center" title="17 Jan 2016, 18:14">3&nbsp;months</td>
			<td class="green center">2884</td>
			<td class="red lasttd center">67</td>
			</tr>
						<tr class="even" id="torrent_spectre11920486">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11920486,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2016-5-1-ch-dublado-1080p-by-luanharper-t11920486.html#comment">4 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2016-5-1-ch-dublado-1080p-by-luanharper-t11920486.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202016%205.1%20CH%20Dublado%201080p%20By-LuanHarper', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:15494316AB2C0EFB938116AB3AAB42F597370108&dn=spectre+2016+5+1+ch+dublado+1080p+by+luanharper&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:15494316AB2C0EFB938116AB3AAB42F597370108&dn=spectre+2016+5+1+ch+dublado+1080p+by+luanharper&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/15494316AB2C0EFB938116AB3AAB42F597370108.torrent?title=[kat.cr]spectre.2016.5.1.ch.dublado.1080p.by.luanharper" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2016-5-1-ch-dublado-1080p-by-luanharper-t11920486.html" class="torType filmType"></a>
                <a href="/spectre-2016-5-1-ch-dublado-1080p-by-luanharper-t11920486.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2016-5-1-ch-dublado-1080p-by-luanharper-t11920486.html" class="cellMainLink"><strong class="red">Spectre</strong> 2016 5.1 CH Dublado 1080p By-LuanHarper</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/LuanHarper/">LuanHarper</a> in <span id="cat_11920486"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.99 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="17 Jan 2016, 14:58">3&nbsp;months</td>
			<td class="green center">571</td>
			<td class="red lasttd center">35</td>
			</tr>
						<tr class="odd" id="torrent_spectre11921850">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11921850,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-french-720p-bluray-x264-amnesia-t11921850.html#comment">5 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-french-720p-bluray-x264-amnesia-t11921850.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20FRENCH%20720p%20BluRay%20x264-AMNESIA', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:D77C43A5629BE5DEE8733719E64813871777817D&dn=spectre+2015+french+720p+bluray+x264+amnesia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:D77C43A5629BE5DEE8733719E64813871777817D&dn=spectre+2015+french+720p+bluray+x264+amnesia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/D77C43A5629BE5DEE8733719E64813871777817D.torrent?title=[kat.cr]spectre.2015.french.720p.bluray.x264.amnesia" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-french-720p-bluray-x264-amnesia-t11921850.html" class="torType filmType"></a>
                <a href="/spectre-2015-french-720p-bluray-x264-amnesia-t11921850.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-french-720p-bluray-x264-amnesia-t11921850.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 FRENCH 720p BluRay x264-AMNESIA</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_11921850"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">5.39 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="17 Jan 2016, 21:01">3&nbsp;months</td>
			<td class="green center">468</td>
			<td class="red lasttd center">29</td>
			</tr>
						<tr class="even" id="torrent_spectre11921851">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11921851,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-multi-1080p-bluray-x264-amnesia-t11921851.html#comment">23 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-multi-1080p-bluray-x264-amnesia-t11921851.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20MULTI%201080p%20BluRay%20x264-AMNESIA', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:F0269426AE1745F9E5B59B7B10ECEBCE9B0AA88D&dn=spectre+2015+multi+1080p+bluray+x264+amnesia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:F0269426AE1745F9E5B59B7B10ECEBCE9B0AA88D&dn=spectre+2015+multi+1080p+bluray+x264+amnesia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/F0269426AE1745F9E5B59B7B10ECEBCE9B0AA88D.torrent?title=[kat.cr]spectre.2015.multi.1080p.bluray.x264.amnesia" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-multi-1080p-bluray-x264-amnesia-t11921851.html" class="torType filmType"></a>
                <a href="/spectre-2015-multi-1080p-bluray-x264-amnesia-t11921851.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-multi-1080p-bluray-x264-amnesia-t11921851.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 MULTI 1080p BluRay x264-AMNESIA</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_11921851"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">11.39 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="17 Jan 2016, 21:01">3&nbsp;months</td>
			<td class="green center">341</td>
			<td class="red lasttd center">47</td>
			</tr>
						<tr class="odd" id="torrent_spectre11917188">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11917188,0" class="icommentjs kaButton smallButton rightButton" href="/007-spectre-2015-1080p-brrip-x264-ac3-evo-t11917188.html#comment">34 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/007-spectre-2015-1080p-brrip-x264-ac3-evo-t11917188.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': '.007%3A%20Spectre%20%282015%29%201080p%20BRRip%20X264%20AC3-EVO', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:0F47ED5946F460533709FDA228345D55705C51B0&dn=007+spectre+2015+1080p+brrip+x264+ac3+evo&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:0F47ED5946F460533709FDA228345D55705C51B0&dn=007+spectre+2015+1080p+brrip+x264+ac3+evo&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/0F47ED5946F460533709FDA228345D55705C51B0.torrent?title=[kat.cr]007.spectre.2015.1080p.brrip.x264.ac3.evo" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/007-spectre-2015-1080p-brrip-x264-ac3-evo-t11917188.html" class="torType filmType"></a>
                <a href="/007-spectre-2015-1080p-brrip-x264-ac3-evo-t11917188.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/007-spectre-2015-1080p-brrip-x264-ac3-evo-t11917188.html" class="cellMainLink">.007: <strong class="red">Spectre</strong> (2015) 1080p BRRip X264 AC3-EVO</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/FireofSword/">FireofSword</a> in <span id="cat_11917188"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">4.62 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="17 Jan 2016, 00:39">3&nbsp;months</td>
			<td class="green center">304</td>
			<td class="red lasttd center">96</td>
			</tr>
						<tr class="even" id="torrent_spectre11920284">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11920284,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-brrip-xvid-etrg-t11920284.html#comment">68 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-brrip-xvid-etrg-t11920284.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20BRRip%20XviD-ETRG', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:4BAEB3FE13431AF510D343A503EB093AB0A1CD33&dn=spectre+2015+brrip+xvid+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:4BAEB3FE13431AF510D343A503EB093AB0A1CD33&dn=spectre+2015+brrip+xvid+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/4BAEB3FE13431AF510D343A503EB093AB0A1CD33.torrent?title=[kat.cr]spectre.2015.brrip.xvid.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-brrip-xvid-etrg-t11920284.html" class="torType filmType"></a>
                <a href="/spectre-2015-brrip-xvid-etrg-t11920284.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-brrip-xvid-etrg-t11920284.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 BRRip XviD-ETRG</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SaM/">SaM</a> in <span id="cat_11920284"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">709.68 <span>MB</span></td>
			<td class="center">6</td>
			<td class="center" title="17 Jan 2016, 14:19">3&nbsp;months</td>
			<td class="green center">161</td>
			<td class="red lasttd center">72</td>
			</tr>
						<tr class="odd" id="torrent_spectre11916555">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11916555,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-1080p-bluray-h264-aac-rarbg-t11916555.html#comment">17 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-1080p-bluray-h264-aac-rarbg-t11916555.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%201080p%20BluRay%20H264%20AAC-RARBG', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:0AEB01760C6F441D5AB1C80E85A85967F3882977&dn=spectre+2015+1080p+bluray+h264+aac+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:0AEB01760C6F441D5AB1C80E85A85967F3882977&dn=spectre+2015+1080p+bluray+h264+aac+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/0AEB01760C6F441D5AB1C80E85A85967F3882977.torrent?title=[kat.cr]spectre.2015.1080p.bluray.h264.aac.rarbg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-1080p-bluray-h264-aac-rarbg-t11916555.html" class="torType filmType"></a>
                <a href="/spectre-2015-1080p-bluray-h264-aac-rarbg-t11916555.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-1080p-bluray-h264-aac-rarbg-t11916555.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 1080p BluRay H264 AAC-RARBG</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/z0n321/">z0n321</a> in <span id="cat_11916555"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.83 <span>GB</span></td>
			<td class="center">7</td>
			<td class="center" title="16 Jan 2016, 21:18">3&nbsp;months</td>
			<td class="green center">160</td>
			<td class="red lasttd center">37</td>
			</tr>
						<tr class="even" id="torrent_spectre11916615">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11916615,0" class="icommentjs kaButton smallButton rightButton" href="/007-contra-spectre-2015-1080p-bluray-dual-dublado-lapumia-t11916615.html#comment">6 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/007-contra-spectre-2015-1080p-bluray-dual-dublado-lapumia-t11916615.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': '007%20Contra%20Spectre%202015%201080p%20BluRay%20DUAL%20%5BDublado%5D%20LAPUMiA', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:124BDEB84023AEC30E85F19A39581EA888274E0E&dn=007+contra+spectre+2015+1080p+bluray+dual+dublado+lapumia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:124BDEB84023AEC30E85F19A39581EA888274E0E&dn=007+contra+spectre+2015+1080p+bluray+dual+dublado+lapumia&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/124BDEB84023AEC30E85F19A39581EA888274E0E.torrent?title=[kat.cr]007.contra.spectre.2015.1080p.bluray.dual.dublado.lapumia" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/007-contra-spectre-2015-1080p-bluray-dual-dublado-lapumia-t11916615.html" class="torType filmType"></a>
                <a href="/007-contra-spectre-2015-1080p-bluray-dual-dublado-lapumia-t11916615.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/007-contra-spectre-2015-1080p-bluray-dual-dublado-lapumia-t11916615.html" class="cellMainLink">007 Contra <strong class="red">Spectre</strong> 2015 1080p BluRay DUAL [Dublado] LAPUMiA</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/lapumia/">lapumia</a> in <span id="cat_11916615"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.22 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="16 Jan 2016, 21:33">3&nbsp;months</td>
			<td class="green center">139</td>
			<td class="red lasttd center">15</td>
			</tr>
						<tr class="odd" id="torrent_spectre12116473">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12116473,0" class="icommentjs kaButton smallButton rightButton" href="/007-spectre-2015-italian-brrip-xvid-bluworld-t12116473.html#comment">1 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/007-spectre-2015-italian-brrip-xvid-bluworld-t12116473.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': '007%20Spectre%202015%20iTALiAN%20BRRip%20XviD%20BLUWORLD', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:3678587C9393D1FD8ABEC9986B7D79DA85D7185F&dn=007+spectre+2015+italian+brrip+xvid+bluworld&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:3678587C9393D1FD8ABEC9986B7D79DA85D7185F&dn=007+spectre+2015+italian+brrip+xvid+bluworld&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/3678587C9393D1FD8ABEC9986B7D79DA85D7185F.torrent?title=[kat.cr]007.spectre.2015.italian.brrip.xvid.bluworld" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/007-spectre-2015-italian-brrip-xvid-bluworld-t12116473.html" class="torType filmType"></a>
                <a href="/007-spectre-2015-italian-brrip-xvid-bluworld-t12116473.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/007-spectre-2015-italian-brrip-xvid-bluworld-t12116473.html" class="cellMainLink">007 <strong class="red">Spectre</strong> 2015 iTALiAN BRRip XviD BLUWORLD</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SPEEDY45/">SPEEDY45</a> in <span id="cat_12116473"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.05 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="21 Feb 2016, 14:26">2&nbsp;months</td>
			<td class="green center">131</td>
			<td class="red lasttd center">12</td>
			</tr>
						<tr class="even" id="torrent_spectre12111263">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12111263,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-bdrip-720p-h264-italian-english-ac3-5-1-sub-multisub-mircrew-t12111263.html#comment">2 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-bdrip-720p-h264-italian-english-ac3-5-1-sub-multisub-mircrew-t12111263.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%20%282015%29%20BDrip%20720p%20H264%20-%20Italian%20English%20Ac3%205%201%20Sub%20MultiSub%20MIRCrew', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:510DB897906DB75514A3EE354489D180C70215EA&dn=spectre+2015+bdrip+720p+h264+italian+english+ac3+5+1+sub+multisub+mircrew&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:510DB897906DB75514A3EE354489D180C70215EA&dn=spectre+2015+bdrip+720p+h264+italian+english+ac3+5+1+sub+multisub+mircrew&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/510DB897906DB75514A3EE354489D180C70215EA.torrent?title=[kat.cr]spectre.2015.bdrip.720p.h264.italian.english.ac3.5.1.sub.multisub.mircrew" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-bdrip-720p-h264-italian-english-ac3-5-1-sub-multisub-mircrew-t12111263.html" class="torType filmType"></a>
                <a href="/spectre-2015-bdrip-720p-h264-italian-english-ac3-5-1-sub-multisub-mircrew-t12111263.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-bdrip-720p-h264-italian-english-ac3-5-1-sub-multisub-mircrew-t12111263.html" class="cellMainLink"><strong class="red">Spectre</strong> (2015) BDrip 720p H264 - Italian English Ac3 5 1 Sub MultiSub MIRCrew</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/robbyrs/">robbyrs</a> in <span id="cat_12111263"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.74 <span>GB</span></td>
			<td class="center">10</td>
			<td class="center" title="20 Feb 2016, 14:10">2&nbsp;months</td>
			<td class="green center">110</td>
			<td class="red lasttd center">26</td>
			</tr>
						<tr class="odd" id="torrent_spectre11920283">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11920283,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-1080p-brrip-x264-aac-etrg-t11920283.html#comment">64 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-1080p-brrip-x264-aac-etrg-t11920283.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%201080p%20BRRip%20x264%20AAC-ETRG', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:3B025F3E2F38F6118A387207BC3CDE5AF966FA25&dn=spectre+2015+1080p+brrip+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:3B025F3E2F38F6118A387207BC3CDE5AF966FA25&dn=spectre+2015+1080p+brrip+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/3B025F3E2F38F6118A387207BC3CDE5AF966FA25.torrent?title=[kat.cr]spectre.2015.1080p.brrip.x264.aac.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-1080p-brrip-x264-aac-etrg-t11920283.html" class="torType filmType"></a>
                <a href="/spectre-2015-1080p-brrip-x264-aac-etrg-t11920283.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-1080p-brrip-x264-aac-etrg-t11920283.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 1080p BRRip x264 AAC-ETRG</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/megaradon/">megaradon</a> in <span id="cat_11920283"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.17 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="17 Jan 2016, 14:19">3&nbsp;months</td>
			<td class="green center">99</td>
			<td class="red lasttd center">19</td>
			</tr>
						<tr class="even" id="torrent_spectre11936063">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11936063,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-1080p-x264-dd5-1-en-nl-subs-t11936063.html#comment">14 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-1080p-x264-dd5-1-en-nl-subs-t11936063.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'SPECTRE%20%282015%29%201080p%20x264%20DD5.1%20EN%20NL%20Subs', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:E09D12017E4D386D19F09825FAEF71D53C57056C&dn=spectre+2015+1080p+x264+dd5+1+en+nl+subs&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:E09D12017E4D386D19F09825FAEF71D53C57056C&dn=spectre+2015+1080p+x264+dd5+1+en+nl+subs&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/E09D12017E4D386D19F09825FAEF71D53C57056C.torrent?title=[kat.cr]spectre.2015.1080p.x264.dd5.1.en.nl.subs" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-1080p-x264-dd5-1-en-nl-subs-t11936063.html" class="torType filmType"></a>
                <a href="/spectre-2015-1080p-x264-dd5-1-en-nl-subs-t11936063.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-1080p-x264-dd5-1-en-nl-subs-t11936063.html" class="cellMainLink"><strong class="red">SPECTRE</strong> (2015) 1080p x264 DD5.1 EN NL Subs</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/sugarbrown13/">sugarbrown13</a> in <span id="cat_11936063"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.94 <span>GB</span></td>
			<td class="center">7</td>
			<td class="center" title="20 Jan 2016, 16:53">3&nbsp;months</td>
			<td class="green center">100</td>
			<td class="red lasttd center">12</td>
			</tr>
						<tr class="odd" id="torrent_spectre12105843">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12105843,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-bdrip-xvid-italian-english-ac3-5-1-sub-multisub-mircrew-t12105843.html#comment">6 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-bdrip-xvid-italian-english-ac3-5-1-sub-multisub-mircrew-t12105843.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%20%282015%29%20BDrip%20XviD%20-%20Italian%20English%20Ac3%205%201%20Sub%20MultiSub%20MIRCrew', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:4A98E2D508E99760F71FF513054135E08EF5C2BE&dn=spectre+2015+bdrip+xvid+italian+english+ac3+5+1+sub+multisub+mircrew&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:4A98E2D508E99760F71FF513054135E08EF5C2BE&dn=spectre+2015+bdrip+xvid+italian+english+ac3+5+1+sub+multisub+mircrew&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/4A98E2D508E99760F71FF513054135E08EF5C2BE.torrent?title=[kat.cr]spectre.2015.bdrip.xvid.italian.english.ac3.5.1.sub.multisub.mircrew" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-bdrip-xvid-italian-english-ac3-5-1-sub-multisub-mircrew-t12105843.html" class="torType filmType"></a>
                <a href="/spectre-2015-bdrip-xvid-italian-english-ac3-5-1-sub-multisub-mircrew-t12105843.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-bdrip-xvid-italian-english-ac3-5-1-sub-multisub-mircrew-t12105843.html" class="cellMainLink"><strong class="red">Spectre</strong> (2015) BDrip XviD - Italian English Ac3 5 1 Sub MultiSub MIRCrew</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/robbyrs/">robbyrs</a> in <span id="cat_12105843"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.52 <span>GB</span></td>
			<td class="center">10</td>
			<td class="center" title="19 Feb 2016, 15:35">2&nbsp;months</td>
			<td class="green center">87</td>
			<td class="red lasttd center">19</td>
			</tr>
						<tr class="even" id="torrent_spectre11917550">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11917550,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-swesub-720p-brrip-x265-swaxxon-t11917550.html#comment">6 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-swesub-720p-brrip-x265-swaxxon-t11917550.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20SweSub%20720p%20BRRip%20x265-SWAXXON', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:A5C5D8E91C50EDA67BE4E3180C6B6FC1F9DB3A79&dn=spectre+2015+swesub+720p+brrip+x265+swaxxon&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A5C5D8E91C50EDA67BE4E3180C6B6FC1F9DB3A79&dn=spectre+2015+swesub+720p+brrip+x265+swaxxon&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/A5C5D8E91C50EDA67BE4E3180C6B6FC1F9DB3A79.torrent?title=[kat.cr]spectre.2015.swesub.720p.brrip.x265.swaxxon" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-swesub-720p-brrip-x265-swaxxon-t11917550.html" class="torType filmType"></a>
                <a href="/spectre-2015-swesub-720p-brrip-x265-swaxxon-t11917550.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-swesub-720p-brrip-x265-swaxxon-t11917550.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 SweSub 720p BRRip x265-SWAXXON</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Swaxxon/">Swaxxon</a> in <span id="cat_11917550"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">755.43 <span>MB</span></td>
			<td class="center">4</td>
			<td class="center" title="17 Jan 2016, 02:42">3&nbsp;months</td>
			<td class="green center">82</td>
			<td class="red lasttd center">8</td>
			</tr>
						<tr class="odd" id="torrent_spectre11915857">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11915857,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-720p-bluray-x264-sparks-rarbg-t11915857.html#comment">25 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-720p-bluray-x264-sparks-rarbg-t11915857.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20720p%20BluRay%20x264-SPARKS%5Brarbg%5D', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:8544D65E33D8368413E9ECA0FA98E5C021E04445&dn=spectre+2015+720p+bluray+x264+sparks+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:8544D65E33D8368413E9ECA0FA98E5C021E04445&dn=spectre+2015+720p+bluray+x264+sparks+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/8544D65E33D8368413E9ECA0FA98E5C021E04445.torrent?title=[kat.cr]spectre.2015.720p.bluray.x264.sparks.rarbg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-720p-bluray-x264-sparks-rarbg-t11915857.html" class="torType filmType"></a>
                <a href="/spectre-2015-720p-bluray-x264-sparks-rarbg-t11915857.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-720p-bluray-x264-sparks-rarbg-t11915857.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 720p BluRay x264-SPARKS[rarbg]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/rwdy/">rwdy</a> in <span id="cat_11915857"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">6.57 <span>GB</span></td>
			<td class="center">6</td>
			<td class="center" title="16 Jan 2016, 18:25">3&nbsp;months</td>
			<td class="green center">77</td>
			<td class="red lasttd center">15</td>
			</tr>
						<tr class="even" id="torrent_spectre12116404">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12116404,0" class="icommentjs kaButton smallButton rightButton" href="/007-spectre-2015-dts-ita-eng-1080p-bluray-x264-bluworld-mkv-t12116404.html#comment">15 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/007-spectre-2015-dts-ita-eng-1080p-bluray-x264-bluworld-mkv-t12116404.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': '007%20Spectre%202015%20DTS%20ITA%20ENG%201080p%20BluRay%20x264-BLUWORLD%20mkv', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:4522346BFEE52688867650DD21FEC3F54F63D637&dn=007+spectre+2015+dts+ita+eng+1080p+bluray+x264+bluworld+mkv&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:4522346BFEE52688867650DD21FEC3F54F63D637&dn=007+spectre+2015+dts+ita+eng+1080p+bluray+x264+bluworld+mkv&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/4522346BFEE52688867650DD21FEC3F54F63D637.torrent?title=[kat.cr]007.spectre.2015.dts.ita.eng.1080p.bluray.x264.bluworld.mkv" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/007-spectre-2015-dts-ita-eng-1080p-bluray-x264-bluworld-mkv-t12116404.html" class="torType filmType"></a>
                <a href="/007-spectre-2015-dts-ita-eng-1080p-bluray-x264-bluworld-mkv-t12116404.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/007-spectre-2015-dts-ita-eng-1080p-bluray-x264-bluworld-mkv-t12116404.html" class="cellMainLink">007 <strong class="red">Spectre</strong> 2015 DTS ITA ENG 1080p BluRay x264-BLUWORLD mkv</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SPEEDY45/">SPEEDY45</a> in <span id="cat_12116404"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">13.15 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="21 Feb 2016, 14:11">2&nbsp;months</td>
			<td class="green center">65</td>
			<td class="red lasttd center">33</td>
			</tr>
						<tr class="odd" id="torrent_spectre12173448">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12173448,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-bdrip-1080p-h264-ita-dts-eng-ac3-sub-ita-eng-t12173448.html#comment">1 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-bdrip-1080p-h264-ita-dts-eng-ac3-sub-ita-eng-t12173448.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%20%282015%29%20%5BBDRip%20-%201080p%20-%20H264%20-%20Ita%20Dts%20Eng%20Ac3%20-%20Sub%20Ita%20Eng%5D', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:BA36C555F8F0596B7D806E03575DBD0A161DD213&dn=spectre+2015+bdrip+1080p+h264+ita+dts+eng+ac3+sub+ita+eng&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:BA36C555F8F0596B7D806E03575DBD0A161DD213&dn=spectre+2015+bdrip+1080p+h264+ita+dts+eng+ac3+sub+ita+eng&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/BA36C555F8F0596B7D806E03575DBD0A161DD213.torrent?title=[kat.cr]spectre.2015.bdrip.1080p.h264.ita.dts.eng.ac3.sub.ita.eng" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-bdrip-1080p-h264-ita-dts-eng-ac3-sub-ita-eng-t12173448.html" class="torType filmType"></a>
                <a href="/spectre-2015-bdrip-1080p-h264-ita-dts-eng-ac3-sub-ita-eng-t12173448.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-bdrip-1080p-h264-ita-dts-eng-ac3-sub-ita-eng-t12173448.html" class="cellMainLink"><strong class="red">Spectre</strong> (2015) [BDRip - 1080p - H264 - Ita Dts Eng Ac3 - Sub Ita Eng]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/giuseppetnt/">giuseppetnt</a> in <span id="cat_12173448"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">12.36 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="01 Mar 2016, 18:22">2&nbsp;months</td>
			<td class="green center">66</td>
			<td class="red lasttd center">28</td>
			</tr>
						<tr class="even" id="torrent_spectre12100526">
            <td>
            <div class="iaconbox center floatright">
                				<a class="icon16" href="/007-spectre-2015-dual-bdrip-xvid-ac3-hqclub-t12100526.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': '007%20%2F%20Spectre%202015%20DUAL%20BDRip%20XviD%20AC3%20-HQCLUB', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:F288BE8D2D55F37B7B785F9C248FCD6B40677893&dn=007+spectre+2015+dual+bdrip+xvid+ac3+hqclub&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:F288BE8D2D55F37B7B785F9C248FCD6B40677893&dn=007+spectre+2015+dual+bdrip+xvid+ac3+hqclub&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/F288BE8D2D55F37B7B785F9C248FCD6B40677893.torrent?title=[kat.cr]007.spectre.2015.dual.bdrip.xvid.ac3.hqclub" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/007-spectre-2015-dual-bdrip-xvid-ac3-hqclub-t12100526.html" class="torType filmType"></a>
                <a href="/007-spectre-2015-dual-bdrip-xvid-ac3-hqclub-t12100526.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/007-spectre-2015-dual-bdrip-xvid-ac3-hqclub-t12100526.html" class="cellMainLink">007 / <strong class="red">Spectre</strong> 2015 DUAL BDRip XviD AC3 -HQCLUB</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Agent.007/">Agent.007</a> in <span id="cat_12100526"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.91 <span>GB</span></td>
			<td class="center">6</td>
			<td class="center" title="18 Feb 2016, 15:36">2&nbsp;months</td>
			<td class="green center">65</td>
			<td class="red lasttd center">3</td>
			</tr>
						<tr class="odd" id="torrent_spectre12021784">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12021784,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-bluray-rip-español-latino-2015-t12021784.html#comment">2 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-bluray-rip-español-latino-2015-t12021784.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%20%5BBluRay%20Rip%5D%5BEspa%C3%B1ol%20Latino%5D%5B2015%5D', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:D9567B4196FD545723F61BCFBB3CAA425C25248A&dn=spectre+bluray+rip+espa%C3%B1ol+latino+2015&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:D9567B4196FD545723F61BCFBB3CAA425C25248A&dn=spectre+bluray+rip+espa%C3%B1ol+latino+2015&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/D9567B4196FD545723F61BCFBB3CAA425C25248A.torrent?title=[kat.cr]spectre.bluray.rip.espa%C3%B1ol.latino.2015" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-bluray-rip-español-latino-2015-t12021784.html" class="torType filmType"></a>
                <a href="/spectre-bluray-rip-español-latino-2015-t12021784.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-bluray-rip-español-latino-2015-t12021784.html" class="cellMainLink"><strong class="red">Spectre</strong> [BluRay Rip][Español Latino][2015]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ByronDSantos/">ByronDSantos</a> in <span id="cat_12021784"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">700.35 <span>MB</span></td>
			<td class="center">3</td>
			<td class="center" title="04 Feb 2016, 22:28">3&nbsp;months</td>
			<td class="green center">51</td>
			<td class="red lasttd center">23</td>
			</tr>
						<tr class="even" id="torrent_spectre12063757">
            <td>
            <div class="iaconbox center floatright">
                <a rel="12063757,0" class="icommentjs kaButton smallButton rightButton" href="/james-bond-007-spectre-2015-720p-bluray-x264-multi-audio-dd-5-1-hindi-dd-5-1-tamil-dd-5-1-telugu-dd-5-1-english-monu987-t12063757.html#comment">5 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/james-bond-007-spectre-2015-720p-bluray-x264-multi-audio-dd-5-1-hindi-dd-5-1-tamil-dd-5-1-telugu-dd-5-1-english-monu987-t12063757.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'James%20Bond%20007%20Spectre%20%282015%29%20720p%20BluRay%20x264%20%5BMulti%20Audio%20DD%205.1%5D%20%5BHindi%20DD%205.1%20-%20Tamil%20DD%205.1%20-%20Telugu%20DD%205.1%20-%20English%5D%20-%20monu987', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:7BA3FD102E08AC54B6CEE92574A6A183CE37AD49&dn=james+bond+007+spectre+2015+720p+bluray+x264+multi+audio+dd+5+1+hindi+dd+5+1+tamil+dd+5+1+telugu+dd+5+1+english+monu987&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:7BA3FD102E08AC54B6CEE92574A6A183CE37AD49&dn=james+bond+007+spectre+2015+720p+bluray+x264+multi+audio+dd+5+1+hindi+dd+5+1+tamil+dd+5+1+telugu+dd+5+1+english+monu987&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/7BA3FD102E08AC54B6CEE92574A6A183CE37AD49.torrent?title=[kat.cr]james.bond.007.spectre.2015.720p.bluray.x264.multi.audio.dd.5.1.hindi.dd.5.1.tamil.dd.5.1.telugu.dd.5.1.english.monu987" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/james-bond-007-spectre-2015-720p-bluray-x264-multi-audio-dd-5-1-hindi-dd-5-1-tamil-dd-5-1-telugu-dd-5-1-english-monu987-t12063757.html" class="torType filmType"></a>
                <a href="/james-bond-007-spectre-2015-720p-bluray-x264-multi-audio-dd-5-1-hindi-dd-5-1-tamil-dd-5-1-telugu-dd-5-1-english-monu987-t12063757.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/james-bond-007-spectre-2015-720p-bluray-x264-multi-audio-dd-5-1-hindi-dd-5-1-tamil-dd-5-1-telugu-dd-5-1-english-monu987-t12063757.html" class="cellMainLink">James Bond 007 <strong class="red">Spectre</strong> (2015) 720p BluRay x264 [Multi Audio DD 5.1] [Hindi DD 5.1 - Tamil DD 5.1 - Telugu DD 5.1 - English] - monu987</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/monu987/">monu987</a> in <span id="cat_12063757"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.75 <span>GB</span></td>
			<td class="center">16</td>
			<td class="center" title="12 Feb 2016, 04:04">2&nbsp;months</td>
			<td class="green center">49</td>
			<td class="red lasttd center">21</td>
			</tr>
						<tr class="odd" id="torrent_spectre11924219">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11924219,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-1080p-bluray-x264-dts-hd-ma-7-1-rarbg-t11924219.html#comment">11 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-1080p-bluray-x264-dts-hd-ma-7-1-rarbg-t11924219.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%201080p%20BluRay%20x264%20DTS-HD%20MA%207%201-RARBG', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:968EE81B6F14012201623E7A5D0049288A8F5520&dn=spectre+2015+1080p+bluray+x264+dts+hd+ma+7+1+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:968EE81B6F14012201623E7A5D0049288A8F5520&dn=spectre+2015+1080p+bluray+x264+dts+hd+ma+7+1+rarbg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/968EE81B6F14012201623E7A5D0049288A8F5520.torrent?title=[kat.cr]spectre.2015.1080p.bluray.x264.dts.hd.ma.7.1.rarbg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-1080p-bluray-x264-dts-hd-ma-7-1-rarbg-t11924219.html" class="torType filmType"></a>
                <a href="/spectre-2015-1080p-bluray-x264-dts-hd-ma-7-1-rarbg-t11924219.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-1080p-bluray-x264-dts-hd-ma-7-1-rarbg-t11924219.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 1080p BluRay x264 DTS-HD MA 7 1-RARBG</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/z0n321/">z0n321</a> in <span id="cat_11924219"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">14.28 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="18 Jan 2016, 09:20">3&nbsp;months</td>
			<td class="green center">49</td>
			<td class="red lasttd center">10</td>
			</tr>
						<tr class="even" id="torrent_spectre11995015">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11995015,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-james-bond-007-multi-audio-eng-fre-por-spa-rus-1080p-hevc-x265-t11995015.html#comment">12 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-james-bond-007-multi-audio-eng-fre-por-spa-rus-1080p-hevc-x265-t11995015.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%20%282015%29%20James%20Bond%20007%20%5BMULTI-AUDIO%5D%20%5BENG%2C%20FRE%2C%20POR%2C%20SPA%2C%20RUS%5D%20%5B1080p%5D%20%5BHEVC%5D%20%5Bx265%5D', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:B583B141503FF248918BCB058176A2151D6C2E53&dn=spectre+2015+james+bond+007+multi+audio+eng+fre+por+spa+rus+1080p+hevc+x265&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:B583B141503FF248918BCB058176A2151D6C2E53&dn=spectre+2015+james+bond+007+multi+audio+eng+fre+por+spa+rus+1080p+hevc+x265&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/B583B141503FF248918BCB058176A2151D6C2E53.torrent?title=[kat.cr]spectre.2015.james.bond.007.multi.audio.eng.fre.por.spa.rus.1080p.hevc.x265" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-james-bond-007-multi-audio-eng-fre-por-spa-rus-1080p-hevc-x265-t11995015.html" class="torType filmType"></a>
                <a href="/spectre-2015-james-bond-007-multi-audio-eng-fre-por-spa-rus-1080p-hevc-x265-t11995015.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-james-bond-007-multi-audio-eng-fre-por-spa-rus-1080p-hevc-x265-t11995015.html" class="cellMainLink"><strong class="red">Spectre</strong> (2015) James Bond 007 [MULTI-AUDIO] [ENG, FRE, POR, SPA, RUS] [1080p] [HEVC] [x265]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/%5BPseudo%5D/">[Pseudo]</a> in <span id="cat_11995015"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.62 <span>GB</span></td>
			<td class="center">12</td>
			<td class="center" title="31 Jan 2016, 02:40">3&nbsp;months</td>
			<td class="green center">45</td>
			<td class="red lasttd center">17</td>
			</tr>
						<tr class="odd" id="torrent_spectre11915873">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11915873,0" class="icommentjs kaButton smallButton rightButton" href="/spectre-2015-720p-bluray-x264-sparks-ethd-t11915873.html#comment">1 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/spectre-2015-720p-bluray-x264-sparks-ethd-t11915873.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Spectre%202015%20720p%20BluRay%20x264-SPARKS%5BEtHD%5D', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:99CC961281D25CBF027B70825341C283AAF5DA9B&dn=spectre+2015+720p+bluray+x264+sparks+ethd&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:99CC961281D25CBF027B70825341C283AAF5DA9B&dn=spectre+2015+720p+bluray+x264+sparks+ethd&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/99CC961281D25CBF027B70825341C283AAF5DA9B.torrent?title=[kat.cr]spectre.2015.720p.bluray.x264.sparks.ethd" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/spectre-2015-720p-bluray-x264-sparks-ethd-t11915873.html" class="torType filmType"></a>
                <a href="/spectre-2015-720p-bluray-x264-sparks-ethd-t11915873.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/spectre-2015-720p-bluray-x264-sparks-ethd-t11915873.html" class="cellMainLink"><strong class="red">Spectre</strong> 2015 720p BluRay x264-SPARKS[EtHD]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/EtHD/">EtHD</a> in <span id="cat_11915873"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">6.62 <span>GB</span></td>
			<td class="center">9</td>
			<td class="center" title="16 Jan 2016, 18:29">3&nbsp;months</td>
			<td class="green center">46</td>
			<td class="red lasttd center">14</td>
			</tr>
			</table>
	<div class="pages botmarg5px floatright" baseurl="/usearch/spectre/">
<a class="turnoverButton siteButton bigButton kaTurnoverButton pagespecify_js" title="Go to a specific page"><i class="ka ka-zoom"></i></a><a class="turnoverButton siteButton bigButton active">1</a><a rel="nofollow" href="/usearch/spectre/2/" class="turnoverButton siteButton bigButton">2</a><a rel="nofollow" href="/usearch/spectre/3/" class="turnoverButton siteButton bigButton">3</a><a rel="nofollow" href="/usearch/spectre/4/" class="turnoverButton siteButton bigButton">4</a><a rel="nofollow" href="/usearch/spectre/5/" class="turnoverButton siteButton bigButton">5</a><a class="turnoverButton siteButton blank nohov"></a> <a rel="nofollow" href="/usearch/spectre/17/" class="turnoverButton siteButton bigButton">17</a>	<script type="text/javascript">
		$(function() {
			if ($('.pages .nohov').length==0)
				$('.pages .kaTurnoverButton').hide();
		});
		$('.pagespecify_js').unbind('click').on('click', function() {
			var pageNum = prompt('Enter page number');
			if (!isNaN(pageNum) && parseInt(pageNum)>0) {
				var url = $(this).parent().attr('baseurl'); var last = $(this).parent().find('a[href]').last();
				var paramStyle = /\/\?page=/.test(last.attr('href')) ? 2 : (/\/\?.*\&page=/.test(last.attr('href')) ? 1 : 0);
				var url_to = paramStyle==0||paramStyle==2 ? (url.substring(0, url.lastIndexOf('/'))+'/'+(paramStyle==2?'?page='+pageNum+url.substring(url.lastIndexOf('/')+1).replace(/^\?([^\=]+=)/, '&$1'):pageNum+url.substring(url.lastIndexOf('/')))) : url+'&page='+pageNum;
				console.log(url_to);
				if (last.is('.ajaxLink')) { // if last button is .ajaxLink then it implies it's being fancyboxed, or at least the destination page(s) should be fancyboxed.
					$('<a href="'+url_to+'"'+(last.is('[rel="nofollow"]')?' rel="nofollow"':'')+'></a>').fancybox().click();
				}else{
					location.href = url_to;
				}
			}
		});
	</script>
</div>
</div>
		<div class="lightgrey">
			Search for "spectre" on <a href="http://torrentz.eu/search?f=spectre">Torrentz.eu</a>
		</div>
		</td>
		<td class="sidebarCell">

<div id="sidebar" >


        <div  data-sc-slot="_119b0a17fab5493361a252d04bf527db"></div>


    	    <div class="spareBlock">
    <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
    <div  data-sc-slot="_7063408f1c01d50e0dc2d833186ce962" data-sc-params="{ 'searchQuery': 'spectre' }"></div>
</div>


        <div class="sliderbox">
<h3><a href="/community/">Latest Forum Threads</a><i id="hideLatestThreads" class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestForum" rel="latestForum" class="showBlockJS">
		<li>
		<a href="/community/show/dmca-d-books-dr-soc/?unread=17673620">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				DMCA&#039;d Books of Dr.Soc
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_2"><a class="plain" href="/user/Dr.Soc./">Dr.Soc.</a></span></span> <time class="timeago" datetime="2016-05-08T01:14:43+00:00">08 May 2016, 01:14</time></span>
	</li>
		<li>
		<a href="/community/show/how-much-gbs-media-do-you-currently-store/?unread=17673618">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				How much GBs of media do you currently store?
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_verified"><a class="plain" href="/user/ChillSpoon/">ChillSpoon</a></span></span> <time class="timeago" datetime="2016-05-08T01:14:23+00:00">08 May 2016, 01:14</time></span>
	</li>
		<li>
		<a href="/community/show/daz-studio-and-poser-stuff-request-thread-v2/?unread=17673617">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Daz Studio and Poser Stuff - Request Thread V2
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_verified"><a class="plain" href="/user/deedee3792/">deedee3792</a></span></span> <time class="timeago" datetime="2016-05-08T01:14:08+00:00">08 May 2016, 01:14</time></span>
	</li>
		<li>
		<a href="/community/show/tv-show-request-v2-thread-99183/?unread=17673616">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				TV Show Request V2
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_1"><a class="plain" href="/user/.45cal/">.45cal</a></span></span> <time class="timeago" datetime="2016-05-08T01:13:56+00:00">08 May 2016, 01:13</time></span>
	</li>
		<li>
		<a href="/community/show/what-tv-show-are-you-watching-right-now-v5/?unread=17673615">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				What TV show are you watching right now? V5
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/Jahanxaib/">Jahanxaib</a></span></span> <time class="timeago" datetime="2016-05-08T01:12:05+00:00">08 May 2016, 01:12</time></span>
	</li>
		<li>
		<a href="/community/show/please-request-ebooks-and-audio-books-here-v14/?unread=17673609">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Please request ebooks and audio books here. V14
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_verified"><a class="plain" href="/user/BookJunkieGrl/">BookJunkieGrl</a></span></span> <time class="timeago" datetime="2016-05-08T01:07:11+00:00">08 May 2016, 01:07</time></span>
	</li>
	</ul>
</div><!-- div class="sliderbox" -->

    <div class="sliderbox">
<h3><a href="/blog/">Latest News</a><i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestNews" rel="latestNews" class="showBlockJS">
	<li>
		<a href="/blog/post/kat-member-remembrance-day/">
			<i class="ka ka16 ka-rss latest-icon"></i>
			<p class="latest-title">
				KAT Member Remembrance Day
			</p>
		</a>
		<span class="explanation">by KickassTorrents <time class="timeago" datetime="2016-04-10T01:00:31+00:00">10 Apr 2016, 01:00</time></span>
	</li>
</ul>
</div><!-- div class="sliderbox" -->
<div class="sliderbox">
<h3>Blogroll<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="blogroll" rel="blogroll" class="showBlockJS">
	<li><a href="/blog/Lostmyticket/post/kat-and-life-how-a-member-loves-life-and-kat/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> KAT and life - how a member loves life and KAT</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/Lostmyticket/">Lostmyticket</a> <time class="timeago" datetime="2016-05-07T18:56:51+00:00">07 May 2016, 18:56</time></span></li>
	<li><a href="/blog/OptimusPr1me/post/mother-s-day-farewell-maman/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Mother&#039;s Day, Farewell Maman</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/OptimusPr1me/">OptimusPr1me</a> <time class="timeago" datetime="2016-05-07T12:10:35+00:00">07 May 2016, 12:10</time></span></li>
	<li><a href="/blog/TheDels/post/happy-birthday-dad/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Happy Birthday Dad!!! ^-^</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/TheDels/">TheDels</a> <time class="timeago" datetime="2016-05-07T06:44:10+00:00">07 May 2016, 06:44</time></span></li>
	<li><a href="/blog/aztevike/post/the-worst-thing-about-living-abroad-as-an-american/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> The Worst Thing About Living &quot;Abroad&quot; ( as an American )</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/aztevike/">aztevike</a> <time class="timeago" datetime="2016-05-07T06:38:14+00:00">07 May 2016, 06:38</time></span></li>
	<li><a href="/blog/RoughJustice/post/knucklehead-news-8-from-the-archives-7-05-2016/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Knucklehead News #8 (from the archives) 7-05-2016</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/RoughJustice/">RoughJustice</a> <time class="timeago" datetime="2016-05-07T00:53:18+00:00">07 May 2016, 00:53</time></span></li>
	<li><a href="/blog/olderthangod/post/in-reply-to-a-member-blog/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> In reply to a member blog..</p></a><span class="explanation">by <a class="plain aclColor_" href="/user/olderthangod/">olderthangod</a> <time class="timeago" datetime="2016-05-06T12:40:20+00:00">06 May 2016, 12:40</time></span></li>
</ul>
</div><!-- div class="sliderbox" -->

    <div class="sliderbox">
<h3>Goodies<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="goodies" rel="goodies" class="showBlockJS">

	<li>
		<a data-nop target="_blank" rel="external" href="http://addons.mozilla.org/en-US/firefox/addon/11412" target="_blank" rel="external">
			<span class="ifirefox thirdPartIcons"></span>Firefox search plugin
		</a>
	</li>

	<li>
		<a data-nop target="_blank" rel="external" href="http://twitter.com/kickasstorrents">
			<span class="ifollow thirdPartIcons"></span>Follow us on Twitter
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="/blog/post/30/">
			<span class="ikat thirdPartIcons"></span>Kickass wallpapers
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="http://www.facebook.com/official.KAT.fanclub">
			<span class="ifacebook thirdPartIcons"></span>Like us on Facebook
		</a>
	</li>

</ul>
</div><!-- div class="sliderbox" -->
    <div class="sliderbox">
<h3>Latest Searches<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestSearches" rel="latestSearches" class="showBlockJS">
	<li>
		<a href="/search/trials/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				trials
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/write%20on%20me/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				write on me
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/baby%20bibi%20noel/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				baby bibi noel
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/spectre/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				spectre
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/mermaid%20violet%20monroe/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				mermaid violet monroe
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/my%20life%20as%20liz%20season/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				my life as liz season
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/audiobook/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				audiobook
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/ash%20vs%20the%20evil%20dead/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				ash vs the evil dead
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/i%20dream%20of%20mimi/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				i dream of mimi
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/batman%2Bvs%2Bsuperman%2B1080p/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				batman+vs+superman+1080p
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/daz3d%20iray%20shaders/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				daz3d iray shaders
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

</ul>
</div><!-- div class="sliderbox" -->
        	<div class="sliderbox">
	<h3>Friends Links<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
    <ul id="friendsLinks" rel="friendsLinks" class="showBlockJS">

		<li>
			<a data-nop href="http://torrents.to/" target="_blank" rel="external">
				<span class="itorrentsto thirdPartIcons"></span>Torrents.to
			</a>
		</li>
		<li>
			<a data-nop href="http://www.torrentdownloads.net/" target="_blank" rel="external">
				<span class="itorrentdownloads thirdPartIcons"></span>Torrent Downloads
			</a>
		</li>




		<li>
			<a data-nop href="http://torrent-finder.info/" target="_blank" rel="external">
				<span class="itorrentfinder thirdPartIcons"></span>Torrent Finder
			</a>
		</li>
	</ul>
</div><!-- div class="sliderbox" -->

</div>
<a class="showSidebar" id="showsidebar" onclick="showSidebar();" style="display:none;"></a>

		</td>
	</tr>
</table>
<div class="rightcell">
</div><!-- div class="rightcell" -->
<div class="leftcell">
</div>
</div>
<div id="translate_site" style="display:none">
    <h3>Select Your Language</h3>
    <div class="textcontent">
        <div style="line-height:140%;-moz-column-width: 12em; -moz-columns: 12em; -webkit-columns: 12em; columns:12em;">
            <ul>
                                <li class="current_lang"><a href="#" onclick="setLanguage('en', '.kat.cr');return false;" class="plain"><strong>English</strong></a></li>
                                <li><a href="#" onclick="setLanguage('af', '.kat.cr');return false;" class="plain">Afrikaans</a></li>
                                <li><a href="#" onclick="setLanguage('al', '.kat.cr');return false;" class="plain">Albanian</a></li>
                                <li><a href="#" onclick="setLanguage('ar', '.kat.cr');return false;" class="plain">Arabic (Modern)</a></li>
                                <li><a href="#" onclick="setLanguage('eu', '.kat.cr');return false;" class="plain">Basque</a></li>
                                <li><a href="#" onclick="setLanguage('bn', '.kat.cr');return false;" class="plain">Bengali</a></li>
                                <li><a href="#" onclick="setLanguage('bs', '.kat.cr');return false;" class="plain">Bosnian</a></li>
                                <li><a href="#" onclick="setLanguage('br', '.kat.cr');return false;" class="plain">Brazilian Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('bg', '.kat.cr');return false;" class="plain">Bulgarian</a></li>
                                <li><a href="#" onclick="setLanguage('ch', '.kat.cr');return false;" class="plain">Chinese Simplified</a></li>
                                <li><a href="#" onclick="setLanguage('tw', '.kat.cr');return false;" class="plain">Chinese Traditional</a></li>
                                <li><a href="#" onclick="setLanguage('hr', '.kat.cr');return false;" class="plain">Croatian</a></li>
                                <li><a href="#" onclick="setLanguage('cz', '.kat.cr');return false;" class="plain">Czech</a></li>
                                <li><a href="#" onclick="setLanguage('da', '.kat.cr');return false;" class="plain">Danish</a></li>
                                <li><a href="#" onclick="setLanguage('nl', '.kat.cr');return false;" class="plain">Dutch</a></li>
                                <li><a href="#" onclick="setLanguage('tl', '.kat.cr');return false;" class="plain">Filipino</a></li>
                                <li><a href="#" onclick="setLanguage('fi', '.kat.cr');return false;" class="plain">Finnish</a></li>
                                <li><a href="#" onclick="setLanguage('fr', '.kat.cr');return false;" class="plain">French</a></li>
                                <li><a href="#" onclick="setLanguage('ka', '.kat.cr');return false;" class="plain">Georgian</a></li>
                                <li><a href="#" onclick="setLanguage('de', '.kat.cr');return false;" class="plain">German</a></li>
                                <li><a href="#" onclick="setLanguage('el', '.kat.cr');return false;" class="plain">Greek</a></li>
                                <li><a href="#" onclick="setLanguage('he', '.kat.cr');return false;" class="plain">Hebrew</a></li>
                                <li><a href="#" onclick="setLanguage('hi', '.kat.cr');return false;" class="plain">Hindi</a></li>
                                <li><a href="#" onclick="setLanguage('hu', '.kat.cr');return false;" class="plain">Hungarian</a></li>
                                <li><a href="#" onclick="setLanguage('id', '.kat.cr');return false;" class="plain">Indonesian</a></li>
                                <li><a href="#" onclick="setLanguage('it', '.kat.cr');return false;" class="plain">Italian</a></li>
                                <li><a href="#" onclick="setLanguage('kn', '.kat.cr');return false;" class="plain">Kannada</a></li>
                                <li><a href="#" onclick="setLanguage('ko', '.kat.cr');return false;" class="plain">Korean</a></li>
                                <li><a href="#" onclick="setLanguage('lv', '.kat.cr');return false;" class="plain">Latvian</a></li>
                                <li><a href="#" onclick="setLanguage('lt', '.kat.cr');return false;" class="plain">Lithuanian</a></li>
                                <li><a href="#" onclick="setLanguage('mk', '.kat.cr');return false;" class="plain">Macedonian</a></li>
                                <li><a href="#" onclick="setLanguage('ml', '.kat.cr');return false;" class="plain">Malayalam</a></li>
                                <li><a href="#" onclick="setLanguage('ms', '.kat.cr');return false;" class="plain">Malaysian</a></li>
                                <li><a href="#" onclick="setLanguage('ne', '.kat.cr');return false;" class="plain">Nepali</a></li>
                                <li><a href="#" onclick="setLanguage('no', '.kat.cr');return false;" class="plain">Norwegian</a></li>
                                <li><a href="#" onclick="setLanguage('pr', '.kat.cr');return false;" class="plain">Pirate</a></li>
                                <li><a href="#" onclick="setLanguage('pl', '.kat.cr');return false;" class="plain">Polish</a></li>
                                <li><a href="#" onclick="setLanguage('pt', '.kat.cr');return false;" class="plain">Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('pa', '.kat.cr');return false;" class="plain">Punjabi</a></li>
                                <li><a href="#" onclick="setLanguage('ro', '.kat.cr');return false;" class="plain">Romanian</a></li>
                                <li><a href="#" onclick="setLanguage('ru', '.kat.cr');return false;" class="plain">Russian</a></li>
                                <li><a href="#" onclick="setLanguage('sr', '.kat.cr');return false;" class="plain">Serbian</a></li>
                                <li><a href="#" onclick="setLanguage('src', '.kat.cr');return false;" class="plain">Serbian-Cyrillic</a></li>
                                <li><a href="#" onclick="setLanguage('bsc', '.kat.cr');return false;" class="plain">Serbian-Cyrillic (ijekavica)</a></li>
                                <li><a href="#" onclick="setLanguage('si', '.kat.cr');return false;" class="plain">Sinhala</a></li>
                                <li><a href="#" onclick="setLanguage('sk', '.kat.cr');return false;" class="plain">Slovak</a></li>
                                <li><a href="#" onclick="setLanguage('sl', '.kat.cr');return false;" class="plain">Slovenian</a></li>
                                <li><a href="#" onclick="setLanguage('es', '.kat.cr');return false;" class="plain">Spanish</a></li>
                                <li><a href="#" onclick="setLanguage('sv', '.kat.cr');return false;" class="plain">Swedish</a></li>
                                <li><a href="#" onclick="setLanguage('ta', '.kat.cr');return false;" class="plain">Tamil</a></li>
                                <li><a href="#" onclick="setLanguage('te', '.kat.cr');return false;" class="plain">Telugu</a></li>
                                <li><a href="#" onclick="setLanguage('tr', '.kat.cr');return false;" class="plain">Turkish</a></li>
                                <li><a href="#" onclick="setLanguage('uk', '.kat.cr');return false;" class="plain">Ukrainian</a></li>
                                <li><a href="#" onclick="setLanguage('ur', '.kat.cr');return false;" class="plain">Urdu</a></li>
                                <li><a href="#" onclick="setLanguage('vi', '.kat.cr');return false;" class="plain">Vietnamese</a></li>
                            </ul>
        </div>
    </div><!-- div class="textcontent" -->
</div>
</div><!--id="main"-->
</div><!--id="wrap"-->

<footer class="lightgrey">
	<ul>
		<li><a class="plain" data-nop href="#translate_site" id="translate_link"><strong>change language</strong></a></li>
		<li><a href="/rules/" class="lower">rules</a></li>
        <li><a href="/ideabox/">idea box</a></li>
        <li><a href="/faq/">FAQ</a></li>
		<li class="lower"><a href="/achievements/">Achievements</a></li>

		<li class="lower"><a href="/latest-searches/">Latest Searches</a></li>
        <li><a href="/request/">torrent requests</a></li>        	</ul>
	<ul>
		<li><a href="/about/">about</a></li>
        		<li><a href="/privacy/">privacy</a></li>
		<li><a href="/dmca/">dmca</a></li>
        		<li><a href="/logos/">logos</a></li>
				<li><a href="/contacts/">contacts</a></li>
        <li><a href="/api/">api</a></li>
        <li><a href="https://kastatus.com">KAT status</a></li>

	</ul>
        </footer>
<a class="feedbackButton eventsButtons" href="/issue/create/" id="feedback"><span>Report a bug</span></a>
    <div  data-sc-slot="_673e31f53f8166159b8e996c4124765b"></div>
        <div  data-sc-slot="_e7050fb15fd39b3e4e99a5be4a57b6ea"></div>
<script>
 sc('addGlobal', 'pagetype', 'other');
</script>
<script type="text/javascript"><!--
document.write("<a style='display:none;' href='http://www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t45.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";h"+escape(document.title.substring(0,80))+";"+Math.random()+
"' alt='' title='LiveInternet' "+
"border='0' width='0' height='0'><\/a>")
//--></script>

</body>
</html>

'''


from magnetic.ehp import Html


dom = Html().feed(html)
for elem in dom.find_all('tr', ('class', ['even', 'odd'])):
    columns = elem.find_all('td')
    if len(columns) == 6:
        name = columns[0](tag='a', select=('class', 'cellMainLink'))  # name
        magnet = columns[0](tag='a', select=('title', 'Torrent magnet link'), attribute="href")  # magnet
        size = columns[1]()  # size
        seeds = columns[4]()  # seeds
        peers = columns[5]()  # peers
        print name
        print magnet
        print size
        print seeds
        print peers
        print '++++++++++++++++'
