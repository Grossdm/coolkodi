# -*- coding: utf-8 -*-

#import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time
import sys
#import xbmc, 
import xbmcgui, xbmcplugin, xbmcaddon
#import urllib
import os


##General vars
__plugin__ = "world wide radio"
__author__ = "ilancoll"
__credits__ = ""
__version__ = "1"
__USERAGENT__ = 'XBMC'
__XBMC_Revision__ = ""
__AddonID__ = 'plugin.audio.worldwideradio'

Addon = xbmcaddon.Addon(__AddonID__)

## Script location
HOME_DIR = Addon.getAddonInfo('path').decode("utf-8")
PICS_DIR = os.path.join(HOME_DIR, 'resources', 'media')
STATIONS_DIR = os.path.join(HOME_DIR, 'resources', 'stations')

STATIONS = \
	('iStream The Hits', "iStreamTheHits"),\
	('iStream Dance', "iStreamDance"),\
	('iStream Feel Good ', "iStreamFeelGood"),\
	('iStream Hot 100 ', "iStreamHot100"),\
	('iStream Variety ', "iStreamVariety"),\
	('All Hits 86.6 ', "AllHits86.6"),\
	('DeepFM ', "DeepFM"),\
	('Hits 94 ', "Hits 94"),\
	('The Great 80s ', "The Great 80s"),\
	('Radio Sunshine', "Radio Sunshine"),\
	('Summer Vibe ', "SummerVibe"),\
	('938 LIVE ', "938LIVE"),\
	('TOP 40 TOEN ', "TOP 40 TOEN"),\
('181.fm - The Mix (70s, 80s, 90..)', "181.fm - The Mix"),\
	('Radio Nostalgia', "Radio Nostalgia"),\
	('billboard top 100', "billboard top 100"),\
	('ALL Time Greatest Radio ( Hits from the 60s,70s,80s,90s! )', "AllTimeGreatestRadio"),\
	('Radio Belleterre ( classics to tomorrows hits! )', "RADIO BELLETERRE"),\
	('Lonestar RADIO GOLD( classics )', "LonestarRadioGold"),\
	('Endless 80S RADIO', "ENDLESS 80S RADIO"),\
	('Rock ZILLA (Legendary Rock)', "ZillaRock"),\
	('SKY.FM Best of the 60s', "skyFM60greatesthits"),\
	('SKY.FM Oldies (the 50-60-70)', "SKYFMOldies"),\
	('SKY.FM 80 Dance', "skyfm80Dance"),\
	('SKY.FM 90 Hits', "SkyFM90Hits"),\
	('SKY.FM Best Of 80', "skyfm80bestof"),\
	('SKY.FM Love Music', "SKYFMLovemusic"),\
	('web lounge', "weblounge"),\
	('ABC Love (Soft music)', "abclove"),\
	('Acoustic FM', "AcousticFM"),\
	('101 Hits Radio', "101 Hits Radio"),\
	('100 hit radio', "100hitradio"),\
	('1FM', "1FM"),\
	('977 adult Hits', "977adultHits"),\
	('977 Todays hits', "977Todayshits"),\
	
	

	  

#handle = int(sys.argv[1])

def show_root_menu():
	for col in STATIONS:
		name = col[0]
		url = os.path.join(STATIONS_DIR, "{0}.strm".format(col[1])) 
		tmb = os.path.join(PICS_DIR, "{0}.png".format(col[1]))
		item = xbmcgui.ListItem(name, iconImage = 'icon.png' , thumbnailImage = tmb)
		item.setProperty('IsPlayable', 'true')
		item.setProperty("IsLive", "true")
		item.setInfo(type = 'audio', infoLabels = {'title' : name})
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, item)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


if not sys.argv[2]:
    ok = show_root_menu()
